from __future__ import annotations

import shutil
import subprocess
import re
from contextlib import AbstractContextManager
from dataclasses import dataclass
from pathlib import Path
from typing import Any


RAW_EXTENSIONS = {".raw", ".dd", ".img", ".bin", ".001"}
EWF_EXTENSIONS = {".e01", ".ex01", ".s01"}
QEMU_EXTENSIONS = {".vhd", ".vhdx", ".vmdk", ".qcow", ".qcow2", ".vdi"}


class ImageDependencyError(RuntimeError):
    pass


class UnsupportedImageError(RuntimeError):
    pass


@dataclass(slots=True)
class FileSystemView:
    fs: Any
    volume: str
    offset: int
    description: str


def image_kind(path: Path, requested: str = "auto") -> str:
    if requested != "auto":
        return requested
    suffix = path.suffix.casefold()
    if suffix in EWF_EXTENSIONS:
        return "ewf"
    if suffix in QEMU_EXTENSIONS:
        return "qemu"
    if suffix in RAW_EXTENSIONS or path.is_file():
        return "raw"
    raise UnsupportedImageError(f"Cannot determine image type for {path}")


def _ewf_segments(path: Path, pyewf: Any) -> list[str]:
    glob_method = getattr(pyewf, "glob", None)
    if callable(glob_method):
        segments = list(glob_method(str(path)))
        if segments:
            return segments
    return [str(path)]


def raw_segments(path: Path) -> list[Path]:
    """Return sequential .001/.002 raw segments when the selected file is split."""
    match = re.fullmatch(r"\.(\d{3,})", path.suffix)
    if not match:
        return [path]
    width = len(match.group(1))
    first = int(match.group(1))
    segments: list[Path] = []
    index = first
    while True:
        candidate = path.with_suffix(f".{index:0{width}d}")
        if not candidate.is_file():
            break
        segments.append(candidate)
        index += 1
    return segments or [path]


def source_segments(path: Path, kind: str) -> list[Path]:
    """List all source files that form an image set for hashing/manifest purposes."""
    if kind == "ewf":
        try:
            import pyewf  # type: ignore

            return [Path(item) for item in _ewf_segments(path, pyewf)]
        except ImportError:
            # E01, E02 ... can still be enumerated before the parser dependency exists.
            match = re.fullmatch(r"(?i)\.(e|ex|s)(\d+)", path.suffix)
            if not match:
                return [path]
            prefix, digits = match.groups()
            width = len(digits)
            items: list[Path] = []
            number = int(digits)
            while True:
                candidate = path.with_suffix(f".{prefix}{number:0{width}d}")
                if not candidate.is_file():
                    break
                items.append(candidate)
                number += 1
            return items or [path]
    if kind == "raw":
        return raw_segments(path)
    return [path]


class ImageSession(AbstractContextManager["ImageSession"]):
    """Open a forensic image without asking the operating system to mount it."""

    def __init__(
        self,
        source: Path,
        work_dir: Path,
        kind: str = "auto",
        qemu_img: str = "qemu-img",
    ) -> None:
        self.source = source.resolve()
        self.work_dir = work_dir.resolve()
        self.kind = image_kind(self.source, kind)
        self.qemu_img = qemu_img
        self.converted_path: Path | None = None
        self.image: Any = None
        self._ewf_handle: Any = None

    def __enter__(self) -> "ImageSession":
        try:
            import pytsk3  # type: ignore
        except ImportError as exc:
            raise ImageDependencyError(
                "pytsk3 is required for image access. Install diskconn[image] or use the Docker image."
            ) from exc
        self._pytsk3 = pytsk3
        open_path = self.source
        if self.kind == "qemu":
            executable = shutil.which(self.qemu_img)
            if not executable:
                raise ImageDependencyError(
                    f"{self.qemu_img} is required for {self.source.suffix} images"
                )
            self.work_dir.mkdir(parents=True, exist_ok=True)
            self.converted_path = self.work_dir / "converted-readonly.raw"
            subprocess.run(
                [executable, "convert", "-p", "-O", "raw", "-S", "4k", str(self.source), str(self.converted_path)],
                check=True,
            )
            open_path = self.converted_path
            self.kind = "raw"
        if self.kind == "ewf":
            try:
                import pyewf  # type: ignore
            except ImportError as exc:
                raise ImageDependencyError(
                    "pyewf/libewf-python is required for E01/Ex01 images"
                ) from exc

            owner = self

            class EwfImgInfo(pytsk3.Img_Info):
                def __init__(self) -> None:
                    self.handle = pyewf.handle()
                    self.handle.open(_ewf_segments(owner.source, pyewf))
                    super().__init__(url="", type=pytsk3.TSK_IMG_TYPE_EXTERNAL)

                def close(self) -> None:
                    self.handle.close()

                def read(self, offset: int, size: int) -> bytes:
                    self.handle.seek(offset)
                    return self.handle.read(size)

                def get_size(self) -> int:
                    return self.handle.get_media_size()

            self.image = EwfImgInfo()
            self._ewf_handle = self.image
        elif self.kind == "raw":
            segments = raw_segments(open_path)
            if len(segments) == 1:
                self.image = pytsk3.Img_Info(str(open_path))
            else:
                class SegmentedImgInfo(pytsk3.Img_Info):
                    def __init__(self) -> None:
                        self.paths = segments
                        self.handles = [item.open("rb") for item in self.paths]
                        self.sizes = [item.stat().st_size for item in self.paths]
                        super().__init__(url="", type=pytsk3.TSK_IMG_TYPE_EXTERNAL)

                    def close(self) -> None:
                        for handle in self.handles:
                            handle.close()

                    def get_size(self) -> int:
                        return sum(self.sizes)

                    def read(self, offset: int, size: int) -> bytes:
                        if offset < 0 or size <= 0:
                            return b""
                        remaining = size
                        position = offset
                        output = bytearray()
                        base = 0
                        for handle, segment_size in zip(self.handles, self.sizes):
                            end = base + segment_size
                            if position >= end:
                                base = end
                                continue
                            inside = max(0, position - base)
                            handle.seek(inside)
                            chunk = handle.read(min(remaining, segment_size - inside))
                            output.extend(chunk)
                            remaining -= len(chunk)
                            position += len(chunk)
                            base = end
                            if remaining <= 0 or not chunk:
                                break
                        return bytes(output)

                self.image = SegmentedImgInfo()
                self._ewf_handle = self.image
        else:
            raise UnsupportedImageError(f"Unsupported image kind: {self.kind}")
        return self

    def filesystems(self) -> list[FileSystemView]:
        pytsk3 = self._pytsk3
        views: list[FileSystemView] = []
        seen_offsets: set[int] = set()
        try:
            volume_info = pytsk3.Volume_Info(self.image)
            block_size = int(volume_info.info.block_size)
            for index, partition in enumerate(volume_info):
                length = int(partition.len)
                offset = int(partition.start) * block_size
                description = partition.desc.decode(errors="replace") if isinstance(partition.desc, bytes) else str(partition.desc)
                desc_lower = description.casefold()
                if length <= 0 or "unalloc" in desc_lower or "metadata" in desc_lower:
                    continue
                try:
                    fs = pytsk3.FS_Info(self.image, offset=offset)
                except Exception:
                    continue
                views.append(FileSystemView(fs, f"vol{index:02d}", offset, description.strip()))
                seen_offsets.add(offset)
        except Exception:
            pass
        if 0 not in seen_offsets:
            try:
                fs = pytsk3.FS_Info(self.image, offset=0)
                views.insert(0, FileSystemView(fs, "vol00", 0, "unpartitioned filesystem"))
            except Exception:
                pass
        if not views:
            raise UnsupportedImageError(
                "No supported filesystem found. The image may be encrypted, damaged, or use an unsupported filesystem."
            )
        return views

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self._ewf_handle is not None:
            try:
                self._ewf_handle.close()
            except Exception:
                pass
        self.image = None
