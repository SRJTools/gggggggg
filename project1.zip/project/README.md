# DiskConn Forensics

أداة Digital Forensics لقراءة صور الأقراص **Read-only وبدون Mount**، وتجميع آثار الاتصالات والأوامر في Timeline موحّد مع GUI وCLI وتقرير HTML مستقل وملفات CSV/JSONL قابلة للتحليل.

> النتيجة هي ما يمكن إثباته من الـartifacts الموجودة داخل الصورة. لا توجد أداة تستطيع استرجاع اتصال لم يسجله النظام أصلًا أو تم حذفه/الكتابة فوقه. التقرير يفرّق بين حدث اتصال فعلي وبين target محفوظ في configuration أو MRU.

## الصيغ المدعومة

- E01 / Ex01 / S01 متعددة الأجزاء عبر `pyewf`.
- RAW / DD / IMG / BIN، بما فيها الصور المجزأة `.001`, `.002`, …
- VHD, VHDX, VMDK, QCOW/QCOW2 وVDI عبر `qemu-img`؛ يتم تحويلها مؤقتًا إلى RAW sparse داخل مجلد القضية ثم حذف النسخة المؤقتة.
- NTFS, FAT/exFAT, ext2/3/4 وملفات أنظمة أخرى يدعمها The Sleuth Kit.

لا يتم استدعاء أوامر mount. الوصول للـfilesystem يتم مباشرة من بايتات الصورة بواسطة The Sleuth Kit، وكل الأدوات الخارجية تعمل على النسخ المستخرجة محليًا.

لأن صور الأقراص مدخلات غير موثوقة وقد تستهدف ثغرات في parsers native، يفضّل تشغيل القضايا داخل VM/WSL/container معزول، بدون صلاحيات Administrator وبدون وصول شبكي، مع إبقاء صورة الدليل الأصلية read-only.

## مصادر الأدلة

- Windows SRUM: استهلاك الشبكة لكل تطبيق، profile/interface، bytes sent/received ومدة الاتصال. SRUM عادة لا يحتوي remote IP.
- Windows EVTX: Sysmon Event 3، Filtering Platform 5152/5154/5156/5157/5158، logon 4624/4625، RDP، WLAN، NetworkProfile، DNS Client وPowerShell 4104.
- Registry: PuTTY sessions وhost keys، WinSCP، RDP MRU/servers، mapped drives، NetworkList وTCP/IP/DHCP.
- PuTTY على Linux وWindows (sessions, host keys, session logs)، WinSCP/FileZilla logs/configs، OpenSSH config/known_hosts، `.rdp`، mRemoteNG، Wi-Fi/VPN/NetworkManager configs.
- Browser history/downloads: Chromium/Chrome/Edge، Firefox وSafari، مع WAL/sidecar files.
- Windows Firewall وUFW، Linux auth/syslog/audit، systemd journal، wtmp/btmp.
- PowerShell PSReadLine، bash/zsh/fish history، RunMRU، PowerShell script blocks وأوامر Windows Scheduled Tasks.
- AnyDesk/TeamViewer traces وIIS/Apache/Nginx access logs.

## التثبيت

يتطلب Python 3.10 أو أحدث. ابدأ داخل Virtual Environment:

```powershell
py -m venv .venv
.venv\Scripts\python -m pip install -U pip
.venv\Scripts\pip install -e ".[full]"
```

حزم `pytsk3`, `pyewf` و`pyesedb` قد تحتاج أدوات بناء أو حزم النظام، وخصوصًا على Windows. إذا لم تتوفر wheels مناسبة، استخدم WSL/Linux أو ثبّت backends كل واحد على حدة. يمكن معرفة ما هو جاهز عبر:

```powershell
.venv\Scripts\diskconn capabilities
```

المحللات الأساسية لـEVTX والRegistry تثبت مع المشروع. SRUM يقبل `pyesedb` أو أداة `esedbexport`. الصور الافتراضية تحتاج `qemu-img`، وwtmp/btmp تحتاج `utmpdump`، وsystemd journals تحتاج `journalctl`.

## الواجهة الرسومية

```powershell
.venv\Scripts\diskconn-gui
```

أو:

```powershell
.venv\Scripts\diskconn gui
```

ومن داخل مجلد المشروع يمكن أيضًا تشغيل `python run_gui.py`.

اختر الصورة، مجلد القضية، اسم/رقم القضية واسم الفاحص، ثم ابدأ التحليل. خيار redaction الآمن مفعل افتراضيًا ويحجب كلمات المرور والتوكنز وقيم query string ومواد المفاتيح الخاصة.

يجب أن يكون مجلد القضية جديدًا أو فارغًا؛ الأداة ترفض دمج نتائج تشغيل سابق حتى لا تختلط الأدلة.

## سطر الأوامر

تحليل E01:

```powershell
diskconn analyze D:\Evidence\PC01.E01 -o D:\Cases\PC01 --case-name "PC01 Network Review" --case-number IR-2026-014 --examiner "Analyst"
```

تحليل RAW مجزأ؛ اختر الجزء الأول:

```powershell
diskconn analyze D:\Evidence\disk.001 -o D:\Cases\Disk01 --image-type raw
```

تحليل مجلد artifacts تم تصديره مسبقًا، وهو مفيد للاختبار أو عندما يقوم منتج آخر بعملية الاستخراج:

```powershell
diskconn analyze-artifacts D:\ExportedRoot -o D:\Cases\ArtifactCase
```

خيارات مهمة:

- `--no-hash`: يتجاوز SHA-256 لتسريع triage، لكنه يقلل ضمان سلامة الدليل.
- `--redaction none`: يبقي القيم الحساسة؛ استخدمه فقط داخل بيئة قضية محمية.
- `--network-commands-only`: لا يصدّر الأوامر غير المتعلقة بالشبكة.
- `--max-records` و`--max-total-records`: حدود حماية من الصور الضخمة.
- `--max-artifact-size 1GB` و`--max-extracted-size 40GB`: حدود مساحة الاستخراج.

## مخرجات القضية

- `report.html`: تقرير احترافي مستقل مع summary وendpoints وtimeline وcommands وmanifest والتحذيرات.
- `case.json`: معلومات القضية، المصدر، hashes، طريقة التحليل والحدود.
- `records.jsonl`: كل النتائج normalized مع record ID وprovenance.
- `timeline.csv`, `connections.csv`, `endpoints.csv`, `commands.txt`.
- `artifact_manifest.json/.csv`: مسار كل artifact داخل الصورة، حجمه وSHA-256 وpartition offset.
- `errors.json`: أي parser مفقود أو artifact تالف؛ وجود تحذير لا يلغي النتائج الأخرى.
- `output_checksums.sha256`: hashes لكل ملفات التقرير والتصدير.
- `artifacts/`: النسخ المقروءة فقط التي جُمعت من الصورة، مع نفس البنية المنطقية لكل volume.

## سلامة النتائج

- لا يتم تعديل صورة الدليل.
- كل نتيجة تحمل `evidence_path`, `volume`, `evidence_offset`, `record_id` ودرجة confidence.
- حفظ configuration مثل PuTTY/RDP/known_hosts لا يثبت نجاح اتصال؛ التقرير يوضح ذلك صراحة.
- Browser history يثبت زيارة مسجلة، وليس packet capture.
- السجلات المشفرة أو المحذوفة أو المعطلة، BitLocker/FileVault/LUKS غير المفتوح، filesystem غير مدعوم، أو dependency ناقصة ستظهر كحدود أو warnings.
- الأداة مخصصة للتحليل المصرح به والحوادث والاستجابة الجنائية فقط.

## الاختبارات

الاختبارات الأساسية لا تحتاج صورة حقيقية أو backends native:

```powershell
python -m unittest discover -s tests -v
```

اختبار E01/RAW الحقيقي يحتاج صورة test سليمة وbackends الموضحة في `diskconn capabilities`.

## بنية المشروع

```text
diskconn/
  analysis.py       case engine, hashing, limits, provenance
  image_access.py   E01/RAW/virtual image access without mount
  collector.py      targeted artifact collection
  extractors/       SRUM, EVTX, Registry, browser, logs, configs
  report.py         HTML/CSV/JSONL exports and checksums
  cli.py            command-line interface
  gui.py            desktop GUI
tests/               synthetic end-to-end tests
```
