from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .artifact_rules import category_for, normalize_evidence_path, should_descend
from .models import Artifact, ExtractionError


@dataclass(slots=True)
class CollectionLimits:
    max_artifact_size: int = 512 * 1024 * 1024
    max_total_size: int = 20 * 1024 * 1024 * 1024


def _decode_name(value: bytes | str | None) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="surrogateescape")
    return str(value or "")


def _safe_relative(evidence_path: str) -> Path:
    parts = []
    for part in normalize_evidence_path(evidence_path).split("/"):
        if not part or part in {".", ".."}:
            continue
        cleaned = part.replace(":", "_").replace("\x00", "_")
        parts.append(cleaned)
    return Path(*parts)


class ArtifactCollector:
    def __init__(
        self,
        destination: Path,
        limits: CollectionLimits,
        on_progress: Callable[[str], None] | None = None,
    ) -> None:
        self.destination = destination
        self.limits = limits
        self.on_progress = on_progress or (lambda _: None)
        self.total_written = 0
        self.artifacts: list[Artifact] = []
        self.errors: list[ExtractionError] = []

    def collect_filesystem(self, view: Any) -> list[Artifact]:
        self.on_progress(f"Scanning {view.volume} at byte offset {view.offset}")
        try:
            root = view.fs.open_dir(path="/")
            self._walk(view, root, "/")
        except Exception as exc:
            self.errors.append(
                ExtractionError(
                    stage="collection",
                    message=str(exc),
                    evidence_path="/",
                    exception_type=type(exc).__name__,
                )
            )
        return self.artifacts

    def _walk(self, view: Any, directory: Any, current_path: str) -> None:
        for entry in directory:
            try:
                name = _decode_name(entry.info.name.name)
                if name in {"", ".", ".."}:
                    continue
                path = normalize_evidence_path(f"{current_path}/{name}")
                meta = entry.info.meta
                if meta is None:
                    continue
                meta_type = int(meta.type)
                pytsk3 = __import__("pytsk3")
                if meta_type == int(pytsk3.TSK_FS_META_TYPE_DIR):
                    if should_descend(path):
                        try:
                            self._walk(view, entry.as_directory(), path)
                        except Exception as exc:
                            self.errors.append(
                                ExtractionError(
                                    stage="collection",
                                    message=str(exc),
                                    evidence_path=path,
                                    exception_type=type(exc).__name__,
                                )
                            )
                    continue
                if meta_type != int(pytsk3.TSK_FS_META_TYPE_REG):
                    continue
                category = category_for(path)
                if category:
                    self._extract_file(view, entry, path, category, int(meta.size or 0))
            except Exception as exc:
                self.errors.append(
                    ExtractionError(
                        stage="collection",
                        message=str(exc),
                        evidence_path=current_path,
                        exception_type=type(exc).__name__,
                    )
                )

    def _extract_file(self, view: Any, entry: Any, path: str, category: str, size: int) -> None:
        if size < 0 or size > self.limits.max_artifact_size:
            self.errors.append(
                ExtractionError("collection", f"Skipped artifact of {size} bytes (size limit)", path)
            )
            return
        if self.total_written + size > self.limits.max_total_size:
            self.errors.append(ExtractionError("collection", "Total extraction limit reached", path))
            return
        output = self.destination / view.volume / _safe_relative(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        offset = 0
        try:
            with output.open("wb") as handle:
                while offset < size:
                    amount = min(1024 * 1024, size - offset)
                    data = entry.read_random(offset, amount)
                    if not data:
                        break
                    handle.write(data)
                    digest.update(data)
                    offset += len(data)
            self.total_written += offset
            artifact = Artifact(
                local_path=str(output),
                evidence_path=path,
                category=category,
                volume=view.volume,
                size=offset,
                sha256=digest.hexdigest(),
                partition_offset=view.offset,
            )
            self.artifacts.append(artifact)
            self.on_progress(f"Extracted {path}")
        except Exception as exc:
            try:
                os.unlink(output)
            except OSError:
                pass
            self.errors.append(
                ExtractionError(
                    stage="collection",
                    message=str(exc),
                    evidence_path=path,
                    exception_type=type(exc).__name__,
                )
            )
