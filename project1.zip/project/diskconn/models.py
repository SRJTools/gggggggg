from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class EvidenceRecord:
    """A normalized record with enough provenance to return to the source artifact."""

    kind: str
    source: str
    event: str
    timestamp: str | None = None
    os: str | None = None
    user: str | None = None
    application: str | None = None
    protocol: str | None = None
    local_address: str | None = None
    local_port: int | str | None = None
    remote_address: str | None = None
    remote_port: int | str | None = None
    direction: str | None = None
    status: str | None = None
    bytes_sent: int | None = None
    bytes_received: int | None = None
    command: str | None = None
    url: str | None = None
    confidence: str = "medium"
    evidence_path: str | None = None
    evidence_offset: str | int | None = None
    volume: str | None = None
    record_id: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class Artifact:
    local_path: str
    evidence_path: str
    category: str
    volume: str = "artifacts"
    size: int | None = None
    sha256: str | None = None
    partition_offset: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ExtractionError:
    stage: str
    message: str
    evidence_path: str | None = None
    extractor: str | None = None
    exception_type: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

