from __future__ import annotations

import hashlib
import ipaddress
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator
from urllib.parse import SplitResult, urlsplit, urlunsplit


HOST_PORT_RE = re.compile(
    r"^(?:\[(?P<ipv6>[^]]+)\]|(?P<host>[^:]+))(?:\:(?P<port>\d{1,5}))?$"
)


def iso_utc(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def windows_filetime(value: int | str | None) -> str | None:
    try:
        number = int(value or 0)
        if number <= 0:
            return None
        return iso_utc(datetime(1601, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=number / 10))
    except (TypeError, ValueError, OverflowError):
        return None


def chrome_time(value: int | str | None) -> str | None:
    try:
        number = int(value or 0)
        if number <= 0:
            return None
        return iso_utc(datetime(1601, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=number))
    except (TypeError, ValueError, OverflowError):
        return None


def unix_time(value: int | float | str | None, microseconds: bool = False) -> str | None:
    try:
        number = float(value or 0)
        if not number:
            return None
        if microseconds:
            number /= 1_000_000
        return iso_utc(datetime.fromtimestamp(number, tz=timezone.utc))
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def json_dumps(value: Any, pretty: bool = False) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        indent=2 if pretty else None,
        sort_keys=pretty,
        default=str,
    )


def iter_text_lines(path: Path) -> Iterator[str]:
    """Read common forensic text encodings without failing on damaged bytes."""
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16", errors="replace")
    elif raw.count(b"\x00") > max(4, len(raw) // 8):
        text = raw.decode("utf-16-le", errors="replace")
    else:
        text = raw.decode("utf-8-sig", errors="replace")
    yield from text.splitlines()


def parse_host_port(value: str, default_port: int | None = None) -> tuple[str | None, int | None]:
    value = value.strip()
    if not value:
        return None, default_port
    match = HOST_PORT_RE.match(value)
    if not match:
        return value, default_port
    host = match.group("ipv6") or match.group("host")
    port = int(match.group("port")) if match.group("port") else default_port
    return host, port


def url_endpoint(url: str) -> tuple[str | None, int | None, str | None]:
    try:
        parsed = urlsplit(url)
        protocol = parsed.scheme.lower() or None
        port = parsed.port
        if port is None:
            port = {"http": 80, "https": 443, "ftp": 21, "ssh": 22}.get(protocol or "")
        return parsed.hostname, port, protocol
    except ValueError:
        return None, None, None


def strip_url_credentials(url: str, strip_query_values: bool = True) -> str:
    try:
        parsed = urlsplit(url)
        host = parsed.hostname or ""
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        try:
            port = parsed.port
        except ValueError:
            port = None
        netloc = f"{host}:{port}" if port else host
        query = ""
        if parsed.query:
            query = "&".join(
                f"{part.split('=', 1)[0]}=<redacted>" if "=" in part else part
                for part in parsed.query.split("&")
            ) if strip_query_values else parsed.query
        clean = SplitResult(parsed.scheme, netloc, parsed.path, query, "")
        return urlunsplit(clean)
    except Exception:
        return url


def public_or_named_host(value: str | None) -> str | None:
    if not value:
        return None
    candidate = value.strip("[] ")
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return candidate


def first(mapping: dict[str, Any], names: Iterable[str]) -> Any:
    lowered = {str(key).casefold(): value for key, value in mapping.items()}
    for name in names:
        if name.casefold() in lowered:
            return lowered[name.casefold()]
    return None

