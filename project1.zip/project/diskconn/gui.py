from __future__ import annotations

import queue
import sys
import threading
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import __version__
from .analysis import AnalysisEngine, AnalysisOptions, AnalysisResult
from .report import aggregate_endpoints


NAVY = "#0b1930"
BLUE = "#1c6fe8"
CYAN = "#31c2d9"
INK = "#172033"
MUTED = "#657189"
BG = "#f3f6fa"
WHITE = "#ffffff"
LINE = "#dce3ee"


class DiskConnApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"DiskConn Forensics {__version__}")
        self.geometry("1180x780")
        self.minsize(980, 680)
        self.configure(bg=BG)
        self.events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.result: AnalysisResult | None = None
        self.worker: threading.Thread | None = None
        self._configure_styles()
        self._variables()
        self._build()
        self.after(120, self._poll_events)

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background=BG)
        style.configure("Card.TFrame", background=WHITE, relief="flat")
        style.configure("TLabel", background=BG, foreground=INK, font=("Segoe UI", 10))
        style.configure("Card.TLabel", background=WHITE, foreground=INK, font=("Segoe UI", 10))
        style.configure("Muted.Card.TLabel", background=WHITE, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=NAVY, foreground=WHITE, font=("Segoe UI Semibold", 22))
        style.configure("Subtitle.TLabel", background=NAVY, foreground="#c6d7ee", font=("Segoe UI", 10))
        style.configure("Section.TLabel", background=WHITE, foreground=NAVY, font=("Segoe UI Semibold", 13))
        style.configure("Metric.TLabel", background=WHITE, foreground=NAVY, font=("Segoe UI Semibold", 22))
        style.configure("Primary.TButton", font=("Segoe UI Semibold", 10), padding=(18, 9), background=BLUE, foreground=WHITE)
        style.map("Primary.TButton", background=[("active", "#155fc9"), ("disabled", "#9eabc0")])
        style.configure("Secondary.TButton", padding=(12, 8), background=WHITE, foreground=INK)
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(18, 9), font=("Segoe UI Semibold", 10))
        style.map("TNotebook.Tab", background=[("selected", WHITE)], foreground=[("selected", BLUE)])
        style.configure("Treeview", rowheight=27, background=WHITE, fieldbackground=WHITE, foreground=INK)
        style.configure("Treeview.Heading", font=("Segoe UI Semibold", 9), background="#edf3fb", foreground="#2c3f5d")

    def _variables(self) -> None:
        self.source_mode = tk.StringVar(value="image")
        self.source = tk.StringVar()
        self.output = tk.StringVar(
            value=str(Path.cwd() / f"DiskConn-Case-{datetime.now().strftime('%Y%m%d-%H%M%S')}")
        )
        self.image_type = tk.StringVar(value="auto")
        self.case_name = tk.StringVar(value="Disk Connection Analysis")
        self.case_number = tk.StringVar()
        self.examiner = tk.StringVar()
        self.redaction = tk.StringVar(value="safe")
        self.hashes = tk.BooleanVar(value=True)
        self.all_commands = tk.BooleanVar(value=True)
        self.max_records = tk.IntVar(value=100_000)
        self.max_total_records = tk.IntVar(value=500_000)
        self.status = tk.StringVar(value="Ready — evidence is always opened read-only without mounting")

    def _build(self) -> None:
        header = tk.Frame(self, bg=NAVY, height=92)
        header.pack(fill="x")
        header.pack_propagate(False)
        title_box = tk.Frame(header, bg=NAVY)
        title_box.pack(side="left", padx=28, pady=18)
        ttk.Label(title_box, text="DiskConn Forensics", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            title_box,
            text="تحليل اتصالات صور الأقراص بدون Mount  •  Offline  •  Read-only",
            style="Subtitle.TLabel",
        ).pack(anchor="w")
        tk.Label(
            header, text=f"v{__version__}", bg="#123a70", fg="#d9e8fa",
            font=("Segoe UI Semibold", 9), padx=10, pady=4,
        ).pack(side="right", padx=28)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=22, pady=(18, 10))
        self.setup_tab = ttk.Frame(self.notebook)
        self.results_tab = ttk.Frame(self.notebook)
        self.activity_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.setup_tab, text="  Case Setup  ")
        self.notebook.add(self.results_tab, text="  Results  ")
        self.notebook.add(self.activity_tab, text="  Activity Log  ")
        self._build_setup()
        self._build_results()
        self._build_activity()

        status_bar = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        status_bar.pack(fill="x", side="bottom")
        self.progress = ttk.Progressbar(status_bar, mode="indeterminate", length=160)
        self.progress.pack(side="left", padx=(18, 12), pady=10)
        tk.Label(status_bar, textvariable=self.status, bg=WHITE, fg=MUTED, anchor="w").pack(
            side="left", fill="x", expand=True
        )

    def _card(self, parent: tk.Widget, padding: int = 18) -> ttk.Frame:
        outer = tk.Frame(parent, bg=LINE)
        inner = ttk.Frame(outer, style="Card.TFrame", padding=padding)
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        return inner

    def _labeled_entry(self, parent: tk.Widget, label: str, variable: tk.Variable, row: int, column: int) -> None:
        ttk.Label(parent, text=label, style="Muted.Card.TLabel").grid(row=row, column=column, sticky="w", pady=(4, 3))
        ttk.Entry(parent, textvariable=variable).grid(row=row + 1, column=column, sticky="ew", padx=(0, 12), pady=(0, 7))

    def _build_setup(self) -> None:
        self.setup_tab.columnconfigure(0, weight=3)
        self.setup_tab.columnconfigure(1, weight=2)
        self.setup_tab.rowconfigure(0, weight=1)

        evidence = self._card(self.setup_tab)
        evidence.master.grid(row=0, column=0, sticky="nsew", padx=(0, 9))
        evidence.columnconfigure(0, weight=1)
        ttk.Label(evidence, text="Evidence source", style="Section.TLabel").grid(row=0, column=0, sticky="w", columnspan=3)
        mode_box = ttk.Frame(evidence, style="Card.TFrame")
        mode_box.grid(row=1, column=0, columnspan=3, sticky="w", pady=(12, 7))
        ttk.Radiobutton(mode_box, text="Disk image (E01 / RAW / virtual disk)", variable=self.source_mode, value="image", command=self._mode_changed).pack(side="left")
        ttk.Radiobutton(mode_box, text="Exported artifact directory", variable=self.source_mode, value="artifacts", command=self._mode_changed).pack(side="left", padx=18)
        ttk.Entry(evidence, textvariable=self.source).grid(row=2, column=0, columnspan=2, sticky="ew", pady=5)
        ttk.Button(evidence, text="Browse…", style="Secondary.TButton", command=self._browse_source).grid(row=2, column=2, padx=(10, 0))
        ttk.Label(evidence, text="Image format", style="Muted.Card.TLabel").grid(row=3, column=0, sticky="w", pady=(12, 3))
        self.image_combo = ttk.Combobox(evidence, textvariable=self.image_type, values=("auto", "ewf", "raw", "qemu"), state="readonly", width=16)
        self.image_combo.grid(row=4, column=0, sticky="w")
        ttk.Label(evidence, text="Case output folder", style="Muted.Card.TLabel").grid(row=5, column=0, sticky="w", pady=(17, 3), columnspan=2)
        ttk.Entry(evidence, textvariable=self.output).grid(row=6, column=0, columnspan=2, sticky="ew", pady=5)
        ttk.Button(evidence, text="Browse…", style="Secondary.TButton", command=self._browse_output).grid(row=6, column=2, padx=(10, 0))

        ttk.Separator(evidence).grid(row=7, column=0, columnspan=3, sticky="ew", pady=17)
        ttk.Label(evidence, text="Case details", style="Section.TLabel").grid(row=8, column=0, sticky="w", columnspan=3)
        detail = ttk.Frame(evidence, style="Card.TFrame")
        detail.grid(row=9, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        detail.columnconfigure((0, 1), weight=1)
        self._labeled_entry(detail, "Case name", self.case_name, 0, 0)
        self._labeled_entry(detail, "Case number", self.case_number, 0, 1)
        self._labeled_entry(detail, "Examiner", self.examiner, 2, 0)
        ttk.Label(detail, text="Notes", style="Muted.Card.TLabel").grid(row=2, column=1, sticky="w", pady=(4, 3))
        self.notes = tk.Text(detail, height=3, relief="solid", borderwidth=1, font=("Segoe UI", 9), wrap="word")
        self.notes.grid(row=3, column=1, sticky="nsew", padx=(0, 12), pady=(0, 7))

        options = self._card(self.setup_tab)
        options.master.grid(row=0, column=1, sticky="nsew", padx=(9, 0))
        options.columnconfigure(0, weight=1)
        ttk.Label(options, text="Analysis options", style="Section.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(options, text="Calculate SHA-256 for source image and artifacts", variable=self.hashes).grid(row=1, column=0, sticky="w", pady=(15, 5))
        ttk.Checkbutton(options, text="Extract all available command-line history", variable=self.all_commands).grid(row=2, column=0, sticky="w", pady=5)
        ttk.Label(options, text="Sensitive values", style="Muted.Card.TLabel").grid(row=3, column=0, sticky="w", pady=(18, 4))
        ttk.Combobox(options, textvariable=self.redaction, values=("safe", "none"), state="readonly").grid(row=4, column=0, sticky="ew")
        ttk.Label(options, text="Safe mode removes passwords, tokens, URL query values, and private key material from exports.", style="Muted.Card.TLabel", wraplength=340).grid(row=5, column=0, sticky="w", pady=(5, 12))
        ttk.Label(options, text="Records per artifact", style="Muted.Card.TLabel").grid(row=6, column=0, sticky="w", pady=(8, 4))
        ttk.Spinbox(options, from_=1_000, to=2_000_000, increment=10_000, textvariable=self.max_records).grid(row=7, column=0, sticky="ew")
        ttk.Label(options, text="Global record limit", style="Muted.Card.TLabel").grid(row=8, column=0, sticky="w", pady=(12, 4))
        ttk.Spinbox(options, from_=10_000, to=5_000_000, increment=50_000, textvariable=self.max_total_records).grid(row=9, column=0, sticky="ew")
        safety = tk.Label(
            options, text="READ-ONLY GUARANTEE\nThe operating system is never asked to mount the image.",
            bg="#eefafd", fg="#176a78", justify="left", anchor="w", padx=12, pady=10,
            font=("Segoe UI Semibold", 9),
        )
        safety.grid(row=10, column=0, sticky="ew", pady=(20, 14))
        self.run_button = ttk.Button(options, text="Start forensic analysis", style="Primary.TButton", command=self._start)
        self.run_button.grid(row=11, column=0, sticky="ew", pady=(8, 0))

    def _build_results(self) -> None:
        metrics = ttk.Frame(self.results_tab)
        metrics.pack(fill="x", pady=(0, 14))
        for index in range(6):
            metrics.columnconfigure(index, weight=1)
        self.metric_vars: dict[str, tk.StringVar] = {}
        names = [
            ("connections", "Connections"), ("unique_remote_endpoints", "Endpoints"),
            ("commands", "Commands"), ("configurations", "Configurations"),
            ("artifacts", "Artifacts"), ("errors", "Warnings"),
        ]
        for column, (key, label) in enumerate(names):
            frame = self._card(metrics, padding=12)
            frame.master.grid(row=0, column=column, sticky="nsew", padx=(0 if column == 0 else 5, 0 if column == 5 else 5))
            variable = tk.StringVar(value="—")
            self.metric_vars[key] = variable
            ttk.Label(frame, textvariable=variable, style="Metric.TLabel").pack(anchor="w")
            ttk.Label(frame, text=label, style="Muted.Card.TLabel").pack(anchor="w")

        table_card = self._card(self.results_tab, padding=14)
        table_card.master.pack(fill="both", expand=True)
        top = ttk.Frame(table_card, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 10))
        ttk.Label(top, text="Remote endpoint summary", style="Section.TLabel").pack(side="left")
        self.open_button = ttk.Button(top, text="Open full HTML report", style="Primary.TButton", command=self._open_report, state="disabled")
        self.open_button.pack(side="right")
        columns = ("address", "port", "protocol", "direction", "count", "first", "last", "sources")
        self.endpoint_tree = ttk.Treeview(table_card, columns=columns, show="headings")
        headings = {"address": "Remote address", "port": "Port", "protocol": "Protocol", "direction": "Direction", "count": "Count", "first": "First seen", "last": "Last seen", "sources": "Sources"}
        widths = {"address": 190, "port": 65, "protocol": 90, "direction": 85, "count": 60, "first": 155, "last": 155, "sources": 260}
        for name in columns:
            self.endpoint_tree.heading(name, text=headings[name])
            self.endpoint_tree.column(name, width=widths[name], stretch=name in {"address", "sources"})
        scroll_y = ttk.Scrollbar(table_card, orient="vertical", command=self.endpoint_tree.yview)
        scroll_x = ttk.Scrollbar(table_card, orient="horizontal", command=self.endpoint_tree.xview)
        self.endpoint_tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.endpoint_tree.pack(fill="both", expand=True, side="left")
        scroll_y.pack(fill="y", side="right")
        scroll_x.pack(fill="x", side="bottom")

    def _build_activity(self) -> None:
        card = self._card(self.activity_tab, padding=14)
        card.master.pack(fill="both", expand=True)
        ttk.Label(card, text="Analysis activity", style="Section.TLabel").pack(anchor="w", pady=(0, 10))
        self.log = tk.Text(card, bg="#0e1b2f", fg="#d7e4f5", insertbackground=WHITE, relief="flat", wrap="word", font=("Cascadia Mono", 9), padx=12, pady=12)
        self.log.pack(fill="both", expand=True)
        self.log.configure(state="disabled")

    def _mode_changed(self) -> None:
        self.image_combo.configure(state="readonly" if self.source_mode.get() == "image" else "disabled")

    def _browse_source(self) -> None:
        if self.source_mode.get() == "artifacts":
            value = filedialog.askdirectory(title="Select exported artifact directory")
        else:
            value = filedialog.askopenfilename(
                title="Select forensic disk image",
                filetypes=[
                    ("Forensic images", "*.E01 *.Ex01 *.raw *.dd *.img *.001 *.vhd *.vhdx *.vmdk *.qcow *.qcow2 *.vdi"),
                    ("All files", "*.*"),
                ],
            )
        if value:
            self.source.set(value)

    def _browse_output(self) -> None:
        value = filedialog.askdirectory(title="Select case output directory")
        if value:
            self.output.set(value)

    def _append_log(self, message: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", f"{datetime.now().strftime('%H:%M:%S')}  {message}\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _start(self) -> None:
        source = Path(self.source.get().strip())
        output = Path(self.output.get().strip())
        if not self.source.get().strip() or not source.exists():
            messagebox.showerror("DiskConn", "Choose a valid evidence source first.")
            return
        if not self.output.get().strip():
            messagebox.showerror("DiskConn", "Choose a case output folder.")
            return
        if output.exists() and not output.is_dir():
            messagebox.showerror("DiskConn", "The selected output path is not a directory.")
            return
        if output.exists() and any(output.iterdir()):
            messagebox.showerror(
                "DiskConn",
                "Choose a new or empty case folder. This prevents artifacts from another run contaminating the evidence set.",
            )
            return
        if self.redaction.get() == "none":
            if not messagebox.askyesno("Sensitive output", "Redaction is disabled. Reports may contain credentials or tokens. Continue?"):
                return
        options = AnalysisOptions(
            source=source,
            output=output,
            source_mode=self.source_mode.get(),
            image_type=self.image_type.get(),
            case_name=self.case_name.get().strip() or "Disk Connection Analysis",
            case_number=self.case_number.get().strip(),
            examiner=self.examiner.get().strip(),
            notes=self.notes.get("1.0", "end").strip(),
            redaction=self.redaction.get(),
            calculate_hashes=self.hashes.get(),
            include_all_commands=self.all_commands.get(),
            max_records_per_artifact=max(1, self.max_records.get()),
            max_total_records=max(1, self.max_total_records.get()),
        )
        self.run_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self.result = None
        self.progress.start(10)
        self.status.set("Analysis running…")
        self.notebook.select(self.activity_tab)
        self._append_log("Case analysis started")
        self._append_log(f"Python runtime: {sys.executable}")
        self.worker = threading.Thread(target=self._work, args=(options,), daemon=True)
        self.worker.start()

    def _work(self, options: AnalysisOptions) -> None:
        try:
            result = AnalysisEngine(lambda message: self.events.put(("progress", message))).analyze(options)
            self.events.put(("complete", result))
        except Exception as exc:
            self.events.put(("error", exc))

    def _poll_events(self) -> None:
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "progress":
                    self.status.set(str(value))
                    self._append_log(str(value))
                elif kind == "complete":
                    self._completed(value)
                elif kind == "error":
                    self._failed(value)
        except queue.Empty:
            pass
        self.after(120, self._poll_events)

    def _completed(self, result: AnalysisResult) -> None:
        self.result = result
        self.progress.stop()
        self.run_button.configure(state="normal")
        self.open_button.configure(state="normal")
        self.status.set(f"Complete — {result.report_path}")
        self._append_log("Analysis completed successfully")
        for key, variable in self.metric_vars.items():
            variable.set(f"{int(result.summary.get(key, 0)):,}")
        self.endpoint_tree.delete(*self.endpoint_tree.get_children())
        for item in aggregate_endpoints(result.records)[:1000]:
            self.endpoint_tree.insert(
                "", "end",
                values=(
                    item["remote_address"], item["remote_port"], item["protocol"],
                    item["direction"], item["count"], item["first_seen"],
                    item["last_seen"], item["sources"],
                ),
            )
        self.notebook.select(self.results_tab)
        messagebox.showinfo("DiskConn", f"Analysis complete.\n\nReport: {result.report_path}")

    def _failed(self, error: Exception) -> None:
        self.progress.stop()
        self.run_button.configure(state="normal")
        self.status.set("Analysis failed")
        self._append_log(f"ERROR: {type(error).__name__}: {error}")
        messagebox.showerror("DiskConn analysis failed", str(error))

    def _open_report(self) -> None:
        if self.result and self.result.report_path.exists():
            webbrowser.open(self.result.report_path.resolve().as_uri())


def main() -> int:
    app = DiskConnApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
