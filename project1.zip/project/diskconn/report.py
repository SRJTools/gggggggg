from __future__ import annotations

import csv
import html
import json
from pathlib import Path
from typing import Any, Iterable

from .models import Artifact, EvidenceRecord, ExtractionError
from .utils import sha256_file


CSV_FIELDS = [
    "record_id",
    "kind",
    "source",
    "event",
    "timestamp",
    "os",
    "user",
    "application",
    "protocol",
    "local_address",
    "local_port",
    "remote_address",
    "remote_port",
    "direction",
    "status",
    "bytes_sent",
    "bytes_received",
    "command",
    "url",
    "confidence",
    "evidence_path",
    "evidence_offset",
    "volume",
    "details",
]


def _json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, default=str),
        encoding="utf-8",
    )


def _csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            clean = dict(row)
            if isinstance(clean.get("details"), dict):
                clean["details"] = json.dumps(clean["details"], ensure_ascii=False, default=str)
            writer.writerow(clean)


def aggregate_endpoints(records: list[EvidenceRecord]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for item in records:
        if item.kind != "connection" or not item.remote_address:
            continue
        key = (
            item.remote_address.casefold(),
            str(item.remote_port or ""),
            item.protocol or "unknown",
            item.direction or "unknown",
        )
        entry = grouped.setdefault(
            key,
            {
                "remote_address": item.remote_address,
                "remote_port": item.remote_port,
                "protocol": item.protocol or "unknown",
                "direction": item.direction or "unknown",
                "count": 0,
                "first_seen": None,
                "last_seen": None,
                "sources": set(),
                "applications": set(),
                "users": set(),
                "statuses": set(),
                "kinds": set(),
                "bytes_sent": 0,
                "bytes_received": 0,
            },
        )
        entry["count"] += 1
        entry["sources"].add(item.source)
        entry["kinds"].add(item.event)
        if item.application:
            entry["applications"].add(item.application)
        if item.user:
            entry["users"].add(item.user)
        if item.status:
            entry["statuses"].add(item.status)
        if item.timestamp:
            if entry["first_seen"] is None or item.timestamp < entry["first_seen"]:
                entry["first_seen"] = item.timestamp
            if entry["last_seen"] is None or item.timestamp > entry["last_seen"]:
                entry["last_seen"] = item.timestamp
        entry["bytes_sent"] += item.bytes_sent or 0
        entry["bytes_received"] += item.bytes_received or 0
    output: list[dict[str, Any]] = []
    for entry in grouped.values():
        clean = dict(entry)
        for name in ("sources", "applications", "users", "statuses", "kinds"):
            clean[name] = "; ".join(sorted(entry[name]))
        output.append(clean)
    output.sort(key=lambda row: (-int(row["count"]), str(row["remote_address"])))
    return output


def _e(value: Any) -> str:
    if value is None:
        return ""
    return html.escape(str(value), quote=True)


def _size(value: int | None) -> str:
    number = int(value or 0)
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    amount = float(number)
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:,.1f} {unit}" if unit != "B" else f"{number:,} B"
        amount /= 1024
    return str(number)


def _table(headers: list[str], rows: Iterable[Iterable[Any]], table_id: str) -> str:
    head = "".join(f"<th>{_e(item)}</th>" for item in headers)
    body = []
    for row in rows:
        body.append("<tr>" + "".join(f"<td>{_e(item)}</td>" for item in row) + "</tr>")
    if not body:
        body.append(f'<tr><td class="empty" colspan="{len(headers)}">No records</td></tr>')
    return (
        f'<div class="table-wrap"><table id="{_e(table_id)}"><thead><tr>{head}</tr></thead>'
        f"<tbody>{''.join(body)}</tbody></table></div>"
    )


def _render_report(
    metadata: dict[str, object],
    summary: dict[str, object],
    records: list[EvidenceRecord],
    artifacts: list[Artifact],
    errors: list[ExtractionError],
    endpoints: list[dict[str, Any]],
) -> str:
    source_rows = [
        (item.get("path"), _size(item.get("size", 0)), item.get("sha256") or "Not calculated")
        for item in metadata.get("source_manifest", [])  # type: ignore[union-attr]
    ]
    endpoint_rows = [
        (
            item["remote_address"], item["remote_port"], item["protocol"], item["direction"],
            item["count"], item["first_seen"], item["last_seen"], item["sources"],
            item["applications"], item["users"], _size(item["bytes_sent"]),
            _size(item["bytes_received"]),
        )
        for item in endpoints[:1000]
    ]
    timeline = [item for item in records if item.timestamp][:5000]
    timeline_rows = [
        (
            item.timestamp, item.kind, item.source, item.event, item.user, item.application,
            item.protocol, item.remote_address, item.remote_port, item.direction, item.status,
            item.confidence,
            item.url or item.command or json.dumps(item.details, ensure_ascii=False, default=str),
            item.evidence_path, item.evidence_offset, item.record_id,
        )
        for item in timeline
    ]
    command_rows = [
        (
            item.timestamp, item.user, item.application, item.command, item.source,
            item.evidence_path, item.evidence_offset, item.record_id,
        )
        for item in records if item.kind == "command"
    ][:2000]
    artifact_rows = [
        (
            item.category, item.volume, item.evidence_path, _size(item.size),
            item.sha256 or "Not calculated", item.partition_offset,
        )
        for item in artifacts[:5000]
    ]
    error_rows = [
        (item.stage, item.extractor, item.evidence_path, item.exception_type, item.message)
        for item in errors[:1000]
    ]
    category_rows = [
        (name, count) for name, count in summary.get("artifact_categories", {}).items()  # type: ignore[union-attr]
    ]
    source_count_rows = [
        (name, count) for name, count in summary.get("by_source", {}).items()  # type: ignore[union-attr]
    ]
    limit_note = (
        "The HTML view is capped at 1,000 endpoints, 5,000 timeline rows, 2,000 commands, "
        "and 5,000 artifacts for browser performance. CSV/JSONL exports contain every result."
    )
    css = """
    :root{--navy:#0b1930;--blue:#1c6fe8;--cyan:#31c2d9;--ink:#172033;--muted:#657189;
    --line:#dce3ee;--paper:#fff;--bg:#f3f6fa;--good:#138a64;--warn:#c47a12;--bad:#c83f4d}
    *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 Inter,Segoe UI,Arial,sans-serif}
    header{background:linear-gradient(120deg,var(--navy),#123a70);color:white;padding:34px max(28px,calc((100% - 1440px)/2))}
    header h1{margin:0 0 5px;font-size:30px;letter-spacing:.2px}header p{margin:0;color:#c6d7ee}
    main{max-width:1440px;margin:0 auto;padding:24px}.grid{display:grid;grid-template-columns:repeat(6,minmax(140px,1fr));gap:14px}
    .card,.section{background:var(--paper);border:1px solid var(--line);border-radius:12px;box-shadow:0 4px 18px #15315b0b}
    .card{padding:16px}.card .value{font-size:26px;font-weight:750;color:var(--navy)}.card .label{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.65px}
    .section{margin-top:18px;padding:20px}.section h2{margin:0 0 12px;font-size:19px}.section h3{margin:18px 0 8px;font-size:15px}
    .meta{display:grid;grid-template-columns:160px 1fr 160px 1fr;gap:8px 16px}.meta dt{color:var(--muted)}.meta dd{margin:0;font-weight:600;overflow-wrap:anywhere}
    .toolbar{display:flex;gap:10px;align-items:center;margin:10px 0}.toolbar input{width:min(440px,100%);padding:9px 11px;border:1px solid var(--line);border-radius:8px}
    .table-wrap{overflow:auto;border:1px solid var(--line);border-radius:9px}table{border-collapse:collapse;width:100%;min-width:780px;font-size:12px}
    th{position:sticky;top:0;background:#edf3fb;color:#2c3f5d;text-align:left;white-space:nowrap}th,td{padding:8px 10px;border-bottom:1px solid #e8edf4;vertical-align:top;max-width:420px;overflow-wrap:anywhere}
    tr:nth-child(even) td{background:#fafcff}tr:hover td{background:#eef6ff}.empty{text-align:center;color:var(--muted);padding:24px}
    .note{border-left:4px solid var(--cyan);background:#eefafd;padding:12px 14px;border-radius:6px}.warning{border-left-color:var(--warn);background:#fff8ec}
    .split{display:grid;grid-template-columns:1fr 1fr;gap:18px}.badge{display:inline-block;padding:2px 7px;border-radius:999px;background:#e8f1ff;color:#1958a7;font-size:11px}
    footer{max-width:1440px;margin:0 auto;padding:4px 24px 28px;color:var(--muted)}
    @media(max-width:1000px){.grid{grid-template-columns:repeat(3,1fr)}.split{grid-template-columns:1fr}.meta{grid-template-columns:130px 1fr}}
    @media print{body{background:white}.section,.card{box-shadow:none;break-inside:avoid}.toolbar{display:none}header{padding:22px}.table-wrap{overflow:visible}th{position:static}}
    """
    script = """
    function filterTable(inputId, tableId){
      const q=document.getElementById(inputId).value.toLowerCase();
      document.querySelectorAll('#'+tableId+' tbody tr').forEach(r=>{r.style.display=r.innerText.toLowerCase().includes(q)?'':'none'});
    }
    """
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(metadata.get('case_name'))} — DiskConn Report</title><style>{css}</style></head><body>
<header><h1>DiskConn Forensic Report</h1><p>Offline connection-artifact analysis • read-only • no operating-system mount</p></header>
<main>
<div class="grid">
  <div class="card"><div class="value">{_e(summary.get('connections'))}</div><div class="label">Connection records</div></div>
  <div class="card"><div class="value">{_e(summary.get('unique_remote_endpoints'))}</div><div class="label">Unique endpoints</div></div>
  <div class="card"><div class="value">{_e(summary.get('commands'))}</div><div class="label">Commands</div></div>
  <div class="card"><div class="value">{_e(summary.get('configurations'))}</div><div class="label">Saved configurations</div></div>
  <div class="card"><div class="value">{_e(summary.get('artifacts'))}</div><div class="label">Artifacts parsed</div></div>
  <div class="card"><div class="value">{_e(summary.get('errors'))}</div><div class="label">Processing warnings</div></div>
</div>
<section class="section"><h2>Case information</h2><dl class="meta">
<dt>Case name</dt><dd>{_e(metadata.get('case_name'))}</dd><dt>Case number</dt><dd>{_e(metadata.get('case_number'))}</dd>
<dt>Examiner</dt><dd>{_e(metadata.get('examiner'))}</dd><dt>Image type</dt><dd>{_e(metadata.get('image_type')).upper()}</dd>
<dt>Started (UTC)</dt><dd>{_e(metadata.get('started_utc'))}</dd><dt>Completed (UTC)</dt><dd>{_e(metadata.get('completed_utc'))}</dd>
<dt>Tool version</dt><dd>{_e(metadata.get('tool_version'))}</dd><dt>Redaction</dt><dd>{_e(metadata.get('redaction'))}</dd>
<dt>Analysis mode</dt><dd><span class="badge">READ ONLY / NO MOUNT</span></dd><dt>Host</dt><dd>{_e(metadata.get('analysis_host'))}</dd>
</dl><h3>Examiner notes</h3><p>{_e(metadata.get('notes')) or '—'}</p></section>
<section class="section"><h2>Evidence integrity</h2>{_table(['Source / segment','Size','SHA-256'],source_rows,'source-table')}</section>
<div class="split"><section class="section"><h2>Sources represented</h2>{_table(['Parser source','Records'],source_count_rows,'sources-table')}</section>
<section class="section"><h2>Collected artifact categories</h2>{_table(['Category','Files'],category_rows,'categories-table')}</section></div>
<section class="section"><h2>Remote endpoint summary</h2><div class="toolbar"><input id="endpoint-filter" oninput="filterTable('endpoint-filter','endpoint-table')" placeholder="Filter endpoints, users, applications…"></div>
{_table(['Remote address','Port','Protocol','Direction','Count','First seen','Last seen','Sources','Applications','Users','Sent','Received'],endpoint_rows,'endpoint-table')}</section>
<section class="section"><h2>Timeline</h2><div class="toolbar"><input id="timeline-filter" oninput="filterTable('timeline-filter','timeline-table')" placeholder="Filter timeline…"></div>
{_table(['Timestamp','Kind','Source','Event','User','Application','Protocol','Remote','Port','Direction','Status','Confidence','Context / details','Evidence path','Offset','Record ID'],timeline_rows,'timeline-table')}</section>
<section class="section"><h2>Command-line evidence</h2><div class="toolbar"><input id="command-filter" oninput="filterTable('command-filter','command-table')" placeholder="Filter commands…"></div>
{_table(['Timestamp','User','Application','Command','Source','Evidence path','Offset','Record ID'],command_rows,'command-table')}</section>
<section class="section"><h2>Artifact manifest</h2>{_table(['Category','Volume','Evidence path','Size','SHA-256','Partition byte offset'],artifact_rows,'artifact-table')}</section>
<section class="section"><h2>Processing warnings</h2>{_table(['Stage','Extractor','Evidence path','Exception','Message'],error_rows,'error-table')}</section>
<section class="section"><h2>Interpretation notes and limitations</h2>
<div class="note"><strong>Evidence meaning:</strong> an observed event, browser visit, firewall entry, or log record is stronger evidence of activity than a saved configuration. A PuTTY session, RDP MRU, known_hosts entry, or Wi-Fi profile identifies a known target but does not by itself prove that a successful connection occurred.</div>
<div class="note warning" style="margin-top:10px"><strong>Completeness:</strong> a disk image cannot reconstruct packets that were never logged. Encrypted volumes, deleted/overwritten records, disabled audit channels, unsupported filesystems, and missing parser dependencies can reduce coverage. SRUM measures application/network usage but usually does not retain remote IP addresses.</div>
<p>{_e(limit_note)}</p></section>
</main><footer>Generated by DiskConn Forensics {_e(metadata.get('tool_version'))}. Preserve this report with the JSON/CSV exports and checksum file.</footer>
<script>{script}</script></body></html>"""


def write_case_outputs(
    output: Path,
    metadata: dict[str, object],
    summary: dict[str, object],
    records: list[EvidenceRecord],
    artifacts: list[Artifact],
    errors: list[ExtractionError],
) -> dict[str, Path]:
    output.mkdir(parents=True, exist_ok=True)
    paths = {
        "case_json": output / "case.json",
        "records_jsonl": output / "records.jsonl",
        "timeline_csv": output / "timeline.csv",
        "connections_csv": output / "connections.csv",
        "endpoints_csv": output / "endpoints.csv",
        "commands_txt": output / "commands.txt",
        "artifact_json": output / "artifact_manifest.json",
        "artifact_csv": output / "artifact_manifest.csv",
        "errors_json": output / "errors.json",
        "report": output / "report.html",
        "checksums": output / "output_checksums.sha256",
    }
    _json(paths["case_json"], metadata)
    with paths["records_jsonl"].open("w", encoding="utf-8") as handle:
        for item in records:
            handle.write(json.dumps(item.as_dict(), ensure_ascii=False, default=str) + "\n")
    rows = [item.as_dict() for item in records]
    _csv(paths["timeline_csv"], rows, CSV_FIELDS)
    _csv(
        paths["connections_csv"],
        (item.as_dict() for item in records if item.kind == "connection"),
        CSV_FIELDS,
    )
    endpoints = aggregate_endpoints(records)
    endpoint_fields = [
        "remote_address", "remote_port", "protocol", "direction", "count", "first_seen",
        "last_seen", "sources", "applications", "users", "statuses", "kinds",
        "bytes_sent", "bytes_received",
    ]
    _csv(paths["endpoints_csv"], endpoints, endpoint_fields)
    with paths["commands_txt"].open("w", encoding="utf-8") as handle:
        for item in records:
            if item.kind != "command":
                continue
            handle.write(
                f"[{item.timestamp or 'unknown time'}] {item.user or '-'} | "
                f"{item.command or ''} | {item.evidence_path or '-'}:{item.evidence_offset or '-'}\n"
            )
    _json(paths["artifact_json"], [item.as_dict() for item in artifacts])
    _csv(
        paths["artifact_csv"],
        (item.as_dict() for item in artifacts),
        ["volume", "partition_offset", "category", "evidence_path", "local_path", "size", "sha256"],
    )
    _json(paths["errors_json"], [item.as_dict() for item in errors])
    paths["report"].write_text(
        _render_report(metadata, summary, records, artifacts, errors, endpoints),
        encoding="utf-8",
    )
    checksum_lines = []
    for name, path in paths.items():
        if name == "checksums" or not path.is_file():
            continue
        digest = sha256_file(path)
        checksum_lines.append(f"{digest}  {path.name}")
    paths["checksums"].write_text("\n".join(checksum_lines) + "\n", encoding="ascii")
    return paths
