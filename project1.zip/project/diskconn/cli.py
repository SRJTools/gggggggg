from __future__ import annotations

import argparse
import importlib
import importlib.util
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Sequence

from . import __version__
from .analysis import AnalysisEngine, AnalysisOptions


def _size(value: str) -> int:
    raw = value.strip().casefold().replace("ib", "b")
    multipliers = {"b": 1, "kb": 1024, "mb": 1024**2, "gb": 1024**3, "tb": 1024**4}
    for suffix in ("tb", "gb", "mb", "kb", "b"):
        if raw.endswith(suffix):
            try:
                return int(float(raw[: -len(suffix)]) * multipliers[suffix])
            except ValueError as exc:
                raise argparse.ArgumentTypeError(f"Invalid size: {value}") from exc
    try:
        return int(raw)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Invalid size: {value}") from exc


def _default_output() -> Path:
    return Path.cwd() / f"DiskConn-Case-{datetime.now().strftime('%Y%m%d-%H%M%S')}"


def _analysis_arguments(parser: argparse.ArgumentParser, image: bool) -> None:
    parser.add_argument("source", type=Path, help="Evidence image" if image else "Artifact directory")
    parser.add_argument("-o", "--output", type=Path, default=None, help="Case output directory")
    parser.add_argument("--case-name", default="Disk Connection Analysis")
    parser.add_argument("--case-number", default="")
    parser.add_argument("--examiner", default="")
    parser.add_argument("--notes", default="")
    parser.add_argument("--redaction", choices=("safe", "none"), default="safe")
    parser.add_argument("--no-hash", action="store_true", help="Skip SHA-256 hashing (faster, less forensic assurance)")
    parser.add_argument("--network-commands-only", action="store_true", help="Exclude non-network shell commands")
    parser.add_argument("--max-records", type=int, default=100_000, help="Maximum rows from each artifact")
    parser.add_argument("--max-total-records", type=int, default=500_000)
    parser.add_argument("--max-artifact-size", type=_size, default=512 * 1024**2)
    parser.add_argument("--max-extracted-size", type=_size, default=20 * 1024**3)
    parser.add_argument("-q", "--quiet", action="store_true")
    if image:
        parser.add_argument("--image-type", choices=("auto", "raw", "ewf", "qemu"), default="auto")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="diskconn",
        description="Read-only/no-mount forensic extraction of connection artifacts from disk images.",
    )
    parser.add_argument("--version", action="version", version=f"DiskConn {__version__}")
    subparsers = parser.add_subparsers(dest="command")
    analyze = subparsers.add_parser("analyze", help="Analyze E01, RAW, or virtual disk image")
    _analysis_arguments(analyze, image=True)
    artifacts = subparsers.add_parser(
        "analyze-artifacts", help="Analyze an already exported filesystem/artifact directory"
    )
    _analysis_arguments(artifacts, image=False)
    subparsers.add_parser("gui", help="Open the desktop interface")
    capability = subparsers.add_parser("capabilities", help="Show installed parser backends")
    capability.add_argument("--json", action="store_true")
    return parser


def capabilities() -> dict[str, dict[str, object]]:
    def module(name: str) -> tuple[bool, str | None]:
        if importlib.util.find_spec(name) is None:
            return False, "module not installed"
        try:
            importlib.import_module(name)
            return True, None
        except Exception as exc:
            return False, f"{type(exc).__name__}: {exc}"

    pytsk_ready, pytsk_error = module("pytsk3")
    pyewf_ready, pyewf_error = module("pyewf")
    evtx_ready, evtx_error = module("Evtx")
    registry_ready, registry_error = module("Registry")
    esedb_ready, esedb_error = module("pyesedb")
    tkinter_ready, tkinter_error = module("tkinter")

    return {
        "image_filesystems": {
            "available": pytsk_ready,
            "error": pytsk_error,
            "requirement": "pytsk3",
            "purpose": "NTFS/FAT/exFAT/ext/HFS filesystem access without mounting",
        },
        "ewf_e01": {
            "available": pyewf_ready,
            "error": pyewf_error,
            "requirement": "libewf-python / pyewf",
            "purpose": "E01/Ex01 segmented evidence images",
        },
        "windows_events": {
            "available": evtx_ready,
            "error": evtx_error,
            "requirement": "python-evtx",
            "purpose": "Windows EVTX",
        },
        "windows_registry": {
            "available": registry_ready,
            "error": registry_error,
            "requirement": "python-registry",
            "purpose": "PuTTY, WinSCP, RDP, network profiles, TCP/IP",
        },
        "srum": {
            "available": esedb_ready or bool(shutil.which("esedbexport")),
            "error": None if esedb_ready or shutil.which("esedbexport") else esedb_error,
            "requirement": "pyesedb or esedbexport",
            "purpose": "Windows SRUM ESE database",
        },
        "virtual_disks": {
            "available": bool(shutil.which("qemu-img")),
            "requirement": "qemu-img",
            "purpose": "VHD/VHDX/VMDK/QCOW/VDI read-only conversion",
        },
        "linux_login_records": {
            "available": bool(shutil.which("utmpdump")),
            "requirement": "utmpdump",
            "purpose": "wtmp/btmp",
        },
        "systemd_journal": {
            "available": bool(shutil.which("journalctl")),
            "requirement": "journalctl",
            "purpose": "offline systemd journals",
        },
        "desktop_gui": {
            "available": tkinter_ready,
            "error": tkinter_error,
            "requirement": "Python Tk",
            "purpose": "desktop interface",
        },
    }


def _run_capabilities(as_json: bool) -> int:
    values = capabilities()
    if as_json:
        print(json.dumps(values, ensure_ascii=False, indent=2))
        return 0
    width = max(len(name) for name in values)
    for name, item in values.items():
        state = "READY" if item["available"] else "MISSING"
        detail = f" [{item['error']}]" if item.get("error") else ""
        print(f"{name:<{width}}  {state:<7}  {item['requirement']} - {item['purpose']}{detail}")
    return 0


def _run_analysis(args: argparse.Namespace, source_mode: str) -> int:
    output = args.output or _default_output()
    progress = (lambda message: None) if args.quiet else (lambda message: print(f"[DiskConn] {message}"))
    options = AnalysisOptions(
        source=args.source,
        output=output,
        source_mode=source_mode,
        image_type=getattr(args, "image_type", "auto"),
        case_name=args.case_name,
        case_number=args.case_number,
        examiner=args.examiner,
        notes=args.notes,
        redaction=args.redaction,
        calculate_hashes=not args.no_hash,
        include_all_commands=not args.network_commands_only,
        max_records_per_artifact=max(1, args.max_records),
        max_total_records=max(1, args.max_total_records),
        max_artifact_size=max(1, args.max_artifact_size),
        max_total_artifact_size=max(1, args.max_extracted_size),
    )
    result = AnalysisEngine(progress).analyze(options)
    print(json.dumps(result.summary, ensure_ascii=False, indent=2))
    print(f"Report: {result.report_path}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 0
    try:
        if args.command == "gui":
            from .gui import main as gui_main

            return gui_main()
        if args.command == "capabilities":
            return _run_capabilities(args.json)
        if args.command == "analyze":
            return _run_analysis(args, "image")
        if args.command == "analyze-artifacts":
            return _run_analysis(args, "artifacts")
    except KeyboardInterrupt:
        print("Analysis cancelled.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"DiskConn error: {exc}", file=sys.stderr)
        return 2
    parser.error(f"Unknown command: {args.command}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
