from __future__ import annotations

import fnmatch
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ArtifactRule:
    category: str
    pattern: str


RULES: tuple[ArtifactRule, ...] = (
    # Windows core stores and network/event telemetry.
    ArtifactRule("srum", "*/windows/system32/sru/srudb.dat"),
    ArtifactRule("registry_software", "*/windows/system32/config/software"),
    ArtifactRule("registry_system", "*/windows/system32/config/system"),
    ArtifactRule("registry_user", "*/users/*/ntuser.dat"),
    ArtifactRule("registry_user", "*/documents and settings/*/ntuser.dat"),
    ArtifactRule("evtx", "*/windows/system32/winevt/logs/*.evtx"),
    ArtifactRule("scheduled_task", "*/windows/system32/tasks/*"),
    ArtifactRule("firewall", "*/windows/system32/logfiles/firewall/*.log*"),
    ArtifactRule("firewall", "*/windows/system32/logfiles/pfirewall.log*"),
    ArtifactRule("wlan_xml", "*/programdata/microsoft/wlansvc/profiles/interfaces/*.xml"),
    ArtifactRule("openssh", "*/programdata/ssh/ssh_config"),
    ArtifactRule("openssh", "*/programdata/ssh/sshd_config"),
    ArtifactRule("linux_log", "*/programdata/ssh/logs/*.log*"),
    ArtifactRule("openssh", "*/users/*/.ssh/known_hosts*"),
    ArtifactRule("openssh", "*/users/*/.ssh/config"),
    ArtifactRule("rdp", "*/users/*/*.rdp"),
    ArtifactRule("client_log", "*/users/*/*putty*.log*"),
    ArtifactRule("client_log", "*/users/*/*winscp*.log*"),
    ArtifactRule("client_log", "*/users/*/*filezilla*.log*"),
    ArtifactRule("shell_history", "*/users/*/appdata/roaming/microsoft/windows/powershell/psreadline/*history.txt"),
    ArtifactRule("shell_history", "*/users/*/appdata/roaming/microsoft/windows/powershell/psreadline/*history.txt.*"),
    ArtifactRule("browser_chrome", "*/users/*/appdata/local/google/chrome/user data/*/history"),
    ArtifactRule("browser_chrome_sidecar", "*/users/*/appdata/local/google/chrome/user data/*/history-*"),
    ArtifactRule("browser_chrome", "*/users/*/appdata/local/microsoft/edge/user data/*/history"),
    ArtifactRule("browser_chrome_sidecar", "*/users/*/appdata/local/microsoft/edge/user data/*/history-*"),
    ArtifactRule("browser_firefox", "*/users/*/appdata/roaming/mozilla/firefox/profiles/*/places.sqlite"),
    ArtifactRule("browser_firefox_sidecar", "*/users/*/appdata/roaming/mozilla/firefox/profiles/*/places.sqlite-*"),
    ArtifactRule("browser_safari", "*/users/*/library/safari/history.db"),
    ArtifactRule("browser_safari_sidecar", "*/users/*/library/safari/history.db-*"),
    ArtifactRule("filezilla", "*/users/*/appdata/roaming/filezilla/recentservers.xml"),
    ArtifactRule("filezilla", "*/users/*/appdata/roaming/filezilla/sitemanager.xml"),
    ArtifactRule("mremoteng", "*/users/*/appdata/roaming/mremoteng/confcons.xml"),
    ArtifactRule("vpn_config", "*/program files/openvpn/config/*.ovpn"),
    ArtifactRule("vpn_config", "*/program files/wireguard/data/configurations/*.conf"),
    ArtifactRule("vpn_config", "*/users/*/openvpn/config/*.ovpn"),
    ArtifactRule("vpn_config", "*/programdata/cisco/cisco anyconnect secure mobility client/profile/*.xml"),
    ArtifactRule("vpn_config", "*/programdata/microsoft/network/connections/pbk/rasphone.pbk"),
    ArtifactRule("vpn_config", "*/users/*/appdata/roaming/microsoft/network/connections/pbk/rasphone.pbk"),
    ArtifactRule("network_config", "*/windows/system32/drivers/etc/hosts"),
    ArtifactRule("remote_support_log", "*/programdata/anydesk/*.trace"),
    ArtifactRule("remote_support_log", "*/users/*/appdata/roaming/anydesk/*.trace"),
    ArtifactRule("remote_support_log", "*/program files/teamviewer/teamviewer*_logfile.log"),
    ArtifactRule("remote_support_log", "*/program files (x86)/teamviewer/teamviewer*_logfile.log"),
    ArtifactRule("remote_support_log", "*/programdata/teamviewer/teamviewer*_logfile.log"),
    ArtifactRule("web_access_log", "*/inetpub/logs/logfiles/*/*.log*"),
    # Linux and Unix-like systems.
    ArtifactRule("linux_log", "*/var/log/auth.log*"),
    ArtifactRule("linux_log", "*/var/log/secure*"),
    ArtifactRule("linux_log", "*/var/log/syslog*"),
    ArtifactRule("linux_log", "*/var/log/messages*"),
    ArtifactRule("linux_log", "*/private/var/log/auth.log*"),
    ArtifactRule("linux_log", "*/private/var/log/system.log*"),
    ArtifactRule("firewall", "*/var/log/ufw.log*"),
    ArtifactRule("firewall", "*/var/log/firewalld*"),
    ArtifactRule("audit", "*/var/log/audit/audit.log*"),
    ArtifactRule("web_access_log", "*/var/log/nginx/*access.log*"),
    ArtifactRule("web_access_log", "*/var/log/apache2/*access.log*"),
    ArtifactRule("web_access_log", "*/var/log/httpd/*access_log*"),
    ArtifactRule("journal", "*/var/log/journal/*/*.journal*"),
    ArtifactRule("login_records", "*/var/log/wtmp*"),
    ArtifactRule("login_records", "*/var/log/btmp*"),
    ArtifactRule("openssh", "*/home/*/.ssh/known_hosts*"),
    ArtifactRule("openssh", "*/home/*/.ssh/config"),
    ArtifactRule("openssh", "*/root/.ssh/known_hosts*"),
    ArtifactRule("openssh", "*/root/.ssh/config"),
    ArtifactRule("putty_linux", "*/home/*/.putty/sessions/*"),
    ArtifactRule("putty_linux", "*/root/.putty/sessions/*"),
    ArtifactRule("client_log", "*/home/*/*putty*.log*"),
    ArtifactRule("client_log", "*/home/*/*winscp*.log*"),
    ArtifactRule("shell_history", "*/home/*/.bash_history"),
    ArtifactRule("shell_history", "*/home/*/.zsh_history"),
    ArtifactRule("shell_history", "*/home/*/.local/share/fish/fish_history"),
    ArtifactRule("shell_history", "*/root/.bash_history"),
    ArtifactRule("shell_history", "*/root/.zsh_history"),
    ArtifactRule("network_config", "*/etc/hosts"),
    ArtifactRule("network_config", "*/etc/resolv.conf"),
    ArtifactRule("network_config", "*/etc/network/interfaces"),
    ArtifactRule("network_config", "*/etc/netplan/*.yaml"),
    ArtifactRule("network_config", "*/etc/netplan/*.yml"),
    ArtifactRule("network_config", "*/private/etc/hosts"),
    ArtifactRule("network_config", "*/private/etc/resolv.conf"),
    ArtifactRule("networkmanager", "*/etc/networkmanager/system-connections/*"),
    ArtifactRule("vpn_config", "*/etc/openvpn/*.conf"),
    ArtifactRule("vpn_config", "*/etc/openvpn/*.ovpn"),
    ArtifactRule("vpn_config", "*/etc/wireguard/*.conf"),
    ArtifactRule("dhcp_lease", "*/var/lib/networkmanager/*.lease"),
    ArtifactRule("dhcp_lease", "*/var/lib/dhcp/*.leases"),
    ArtifactRule("browser_chrome", "*/home/*/.config/google-chrome/*/history"),
    ArtifactRule("browser_chrome_sidecar", "*/home/*/.config/google-chrome/*/history-*"),
    ArtifactRule("browser_chrome", "*/home/*/.config/chromium/*/history"),
    ArtifactRule("browser_firefox", "*/home/*/.mozilla/firefox/*/places.sqlite"),
    ArtifactRule("browser_firefox_sidecar", "*/home/*/.mozilla/firefox/*/places.sqlite-*"),
    # macOS user traces.
    ArtifactRule("openssh", "*/users/*/.ssh/known_hosts*"),
    ArtifactRule("openssh", "*/users/*/.ssh/config"),
    ArtifactRule("shell_history", "*/users/*/.bash_history"),
    ArtifactRule("shell_history", "*/users/*/.zsh_history"),
    ArtifactRule("browser_chrome", "*/users/*/library/application support/google/chrome/*/history"),
    ArtifactRule("browser_firefox", "*/users/*/library/application support/firefox/profiles/*/places.sqlite"),
    ArtifactRule("browser_safari", "*/users/*/library/safari/history.db"),
    ArtifactRule("browser_safari_sidecar", "*/users/*/library/safari/history.db-*"),
)


def normalize_evidence_path(path: str) -> str:
    normalized = "/" + path.replace("\\", "/").lstrip("/")
    while "//" in normalized:
        normalized = normalized.replace("//", "/")
    return normalized


def category_for(path: str) -> str | None:
    candidate = normalize_evidence_path(path).casefold()
    for rule in RULES:
        if fnmatch.fnmatchcase(candidate, rule.pattern):
            return rule.category
    return None


INTERESTING_ROOTS = {
    "windows",
    "users",
    "documents and settings",
    "programdata",
    "program files",
    "program files (x86)",
    "home",
    "root",
    "var",
    "etc",
    "library",
    "private",
    "system",
    "opt",
}


def should_descend(path: str) -> bool:
    """Prune obvious data volumes while preserving known OS/user roots."""
    parts = [part.casefold() for part in normalize_evidence_path(path).split("/") if part]
    if not parts:
        return True
    return parts[0] in INTERESTING_ROOTS
