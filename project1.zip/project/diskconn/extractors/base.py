from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Protocol

from ..models import Artifact, EvidenceRecord
from ..redaction import Redactor


@dataclass(slots=True)
class ExtractorContext:
    redactor: Redactor
    max_records: int = 100_000
    include_all_commands: bool = True


class Extractor(Protocol):
    name: str
    categories: frozenset[str]

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]: ...


def local_path(artifact: Artifact) -> Path:
    return Path(artifact.local_path)


def infer_user(evidence_path: str) -> str | None:
    path = evidence_path.replace("\\", "/")
    patterns = (
        r"(?i)/users/([^/]+)/",
        r"(?i)/documents and settings/([^/]+)/",
        r"(?i)/home/([^/]+)/",
    )
    for pattern in patterns:
        match = re.search(pattern, path)
        if match:
            return match.group(1)
    if path.casefold().startswith("/root/"):
        return "root"
    return None


def record(artifact: Artifact, **values: object) -> EvidenceRecord:
    values.setdefault("evidence_path", artifact.evidence_path)
    values.setdefault("volume", artifact.volume)
    return EvidenceRecord(**values)  # type: ignore[arg-type]

