from __future__ import annotations

import re
import struct
import urllib.parse
from datetime import datetime, timezone
from typing import Any, Iterable, Iterator

from ..models import Artifact, EvidenceRecord
from ..utils import iso_utc, parse_host_port, unix_time
from .base import ExtractorContext, infer_user, local_path, record
from .text import NETWORK_COMMAND


def _values(key: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for value in key.values():
        try:
            result[value.name()] = value.value()
        except Exception:
            continue
    return result


def _open(registry: Any, path: str) -> Any | None:
    try:
        return registry.open(path)
    except Exception:
        return None


def _key_time(key: Any) -> str | None:
    try:
        return iso_utc(key.timestamp())
    except Exception:
        return None


def _systemtime(value: Any) -> str | None:
    if not isinstance(value, bytes) or len(value) < 16:
        return None
    try:
        year, month, _, day, hour, minute, second, millisecond = struct.unpack("<8H", value[:16])
        return iso_utc(datetime(year, month, day, hour, minute, second, millisecond * 1000, tzinfo=timezone.utc))
    except (ValueError, struct.error):
        return None


def _string(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bytes):
        for encoding in ("utf-16-le", "utf-8"):
            try:
                return value.decode(encoding).rstrip("\x00")
            except UnicodeDecodeError:
                pass
        return value.hex()
    if isinstance(value, (list, tuple)):
        return "; ".join(str(item) for item in value)
    return str(value)


class RegistryExtractor:
    name = "windows_registry"
    categories = frozenset({"registry_user", "registry_software", "registry_system"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        try:
            from Registry import Registry  # type: ignore
        except ImportError as exc:
            raise RuntimeError("python-registry is required to parse Windows hives") from exc
        registry = Registry.Registry(str(local_path(artifact)))
        if artifact.category == "registry_user":
            yield from self._user_hive(artifact, registry, context)
        elif artifact.category == "registry_software":
            yield from self._software_hive(artifact, registry, context)
        else:
            yield from self._system_hive(artifact, registry, context)

    def _user_hive(self, artifact: Artifact, registry: Any, context: ExtractorContext) -> Iterator[EvidenceRecord]:
        profile_user = infer_user(artifact.evidence_path)
        putty = _open(registry, r"Software\SimonTatham\PuTTY\Sessions")
        if putty:
            for session in putty.subkeys():
                values = _values(session)
                host = _string(values.get("HostName"))
                if not host:
                    continue
                protocol = _string(values.get("Protocol")) or "ssh"
                default_port = 22 if protocol == "ssh" else 23 if protocol == "telnet" else None
                port_value = values.get("PortNumber", default_port)
                yield record(
                    artifact,
                    kind="configuration",
                    source="putty_registry",
                    event="saved_session",
                    timestamp=_key_time(session),
                    os="windows",
                    user=_string(values.get("UserName")) or profile_user,
                    application="PuTTY",
                    protocol=protocol,
                    remote_address=host,
                    remote_port=port_value,
                    direction="outbound",
                    confidence="high",
                    details=context.redactor.mapping({
                        "session": urllib.parse.unquote(session.name()),
                        "proxy_host": _string(values.get("ProxyHost")),
                        "proxy_port": values.get("ProxyPort"),
                        "log_file": _string(values.get("LogFileName")),
                        "public_key_file": _string(values.get("PublicKeyFile")),
                    }),
                )
        host_keys = _open(registry, r"Software\SimonTatham\PuTTY\SshHostKeys")
        if host_keys:
            for value in host_keys.values():
                match = re.match(r"(?P<type>[^@]+)@(?P<port>\d+):(?P<host>.+)", value.name())
                if not match:
                    continue
                yield record(
                    artifact,
                    kind="configuration",
                    source="putty_registry",
                    event="ssh_host_key",
                    timestamp=_key_time(host_keys),
                    os="windows",
                    user=profile_user,
                    application="PuTTY",
                    protocol="ssh",
                    remote_address=match.group("host"),
                    remote_port=int(match.group("port")),
                    direction="outbound",
                    confidence="high",
                    details={"key_type": match.group("type"), "fingerprint_value": _string(value.value())},
                )
        winscp = _open(registry, r"Software\Martin Prikryl\WinSCP 2\Sessions")
        if winscp:
            for session in winscp.subkeys():
                values = _values(session)
                host = _string(values.get("HostName"))
                if not host:
                    continue
                port = values.get("PortNumber", 22)
                fs_protocol = _string(values.get("FSProtocol")) or "sftp"
                yield record(
                    artifact,
                    kind="configuration",
                    source="winscp_registry",
                    event="saved_session",
                    timestamp=_key_time(session),
                    os="windows",
                    user=_string(values.get("UserName")) or profile_user,
                    application="WinSCP",
                    protocol=fs_protocol,
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    confidence="high",
                    details=context.redactor.mapping({
                        "session": urllib.parse.unquote(session.name()),
                        "tunnel_host": _string(values.get("TunnelHostName")),
                        "tunnel_port": values.get("TunnelPortNumber"),
                    }),
                )
        rdp_servers = _open(registry, r"Software\Microsoft\Terminal Server Client\Servers")
        if rdp_servers:
            for server in rdp_servers.subkeys():
                values = _values(server)
                host, port = parse_host_port(server.name(), 3389)
                yield record(
                    artifact,
                    kind="configuration",
                    source="rdp_registry",
                    event="known_rdp_server",
                    timestamp=_key_time(server),
                    os="windows",
                    user=_string(values.get("UsernameHint")) or profile_user,
                    application="Remote Desktop",
                    protocol="rdp",
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    confidence="high",
                )
        rdp_default = _open(registry, r"Software\Microsoft\Terminal Server Client\Default")
        if rdp_default:
            for name, value in _values(rdp_default).items():
                if not name.upper().startswith("MRU"):
                    continue
                host, port = parse_host_port(_string(value) or "", 3389)
                yield record(
                    artifact,
                    kind="configuration",
                    source="rdp_registry",
                    event="rdp_mru",
                    timestamp=_key_time(rdp_default),
                    os="windows",
                    user=profile_user,
                    application="Remote Desktop",
                    protocol="rdp",
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    confidence="high",
                    details={"mru_slot": name},
                )
        network = _open(registry, r"Network")
        if network:
            for drive in network.subkeys():
                values = _values(drive)
                remote = _string(values.get("RemotePath"))
                if remote:
                    remote_host = remote
                    unc = re.match(r"^\\\\([^\\]+)", remote)
                    if unc:
                        remote_host = unc.group(1)
                    yield record(
                        artifact,
                        kind="configuration",
                        source="mapped_drive_registry",
                        event="mapped_network_drive",
                        timestamp=_key_time(drive),
                        os="windows",
                        user=profile_user,
                        application="Windows Explorer",
                        protocol="smb",
                        remote_address=remote_host,
                        remote_port=445,
                        direction="outbound",
                        confidence="high",
                        details={"drive": drive.name(), "provider": _string(values.get("ProviderName")), "remote_path": remote},
                    )
        run_mru = _open(registry, r"Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU")
        if run_mru:
            for name, value in _values(run_mru).items():
                command = _string(value)
                if name == "MRUList" or not command:
                    continue
                yield record(
                    artifact,
                    kind="command",
                    source="run_mru_registry",
                    event="network_command" if NETWORK_COMMAND.search(command) else "command",
                    timestamp=_key_time(run_mru),
                    os="windows",
                    user=profile_user,
                    command=context.redactor.text(command.rstrip("\\1")),
                    confidence="high",
                    details={"mru_slot": name},
                )

    def _software_hive(self, artifact: Artifact, registry: Any, context: ExtractorContext) -> Iterator[EvidenceRecord]:
        profiles = _open(registry, r"Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles")
        if profiles:
            for profile in profiles.subkeys():
                values = _values(profile)
                name = _string(values.get("ProfileName")) or profile.name()
                yield record(
                    artifact,
                    kind="connection",
                    source="windows_networklist",
                    event="network_profile",
                    timestamp=_systemtime(values.get("DateLastConnected")) or _key_time(profile),
                    os="windows",
                    protocol="network_profile",
                    remote_address=name,
                    status="known_network",
                    confidence="high",
                    details=context.redactor.mapping({
                        "profile_guid": profile.name(),
                        "description": _string(values.get("Description")),
                        "managed": values.get("Managed"),
                        "category": values.get("Category"),
                        "date_created": _systemtime(values.get("DateCreated")),
                        "date_last_connected": _systemtime(values.get("DateLastConnected")),
                    }),
                )
        for signature_type in ("Managed", "Unmanaged"):
            signatures = _open(
                registry,
                rf"Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures\{signature_type}",
            )
            if not signatures:
                continue
            for signature in signatures.subkeys():
                values = _values(signature)
                yield record(
                    artifact,
                    kind="configuration",
                    source="windows_network_signature",
                    event="network_signature",
                    timestamp=_key_time(signature),
                    os="windows",
                    remote_address=_string(values.get("DnsSuffix")) or _string(values.get("DefaultGatewayMac")),
                    confidence="high",
                    details=context.redactor.mapping({
                        "signature_type": signature_type,
                        "profile_guid": _string(values.get("ProfileGuid")),
                        "dns_suffix": _string(values.get("DnsSuffix")),
                        "first_network": _string(values.get("FirstNetwork")),
                        "default_gateway_mac": _string(values.get("DefaultGatewayMac")),
                    }),
                )

    def _system_hive(self, artifact: Artifact, registry: Any, context: ExtractorContext) -> Iterator[EvidenceRecord]:
        select = _open(registry, "Select")
        current = int(_values(select).get("Current", 1)) if select else 1
        control_set = f"ControlSet{current:03d}"
        interfaces = _open(registry, rf"{control_set}\Services\Tcpip\Parameters\Interfaces")
        if interfaces:
            for interface in interfaces.subkeys():
                values = _values(interface)
                address = _string(values.get("DhcpIPAddress")) or _string(values.get("IPAddress"))
                if not address:
                    continue
                lease_time = values.get("LeaseObtainedTime")
                yield record(
                    artifact,
                    kind="configuration",
                    source="windows_tcpip_registry",
                    event="network_interface",
                    timestamp=unix_time(lease_time) or _key_time(interface),
                    os="windows",
                    local_address=address,
                    confidence="high",
                    details=context.redactor.mapping({
                        "interface_guid": interface.name(),
                        "dhcp_server": _string(values.get("DhcpServer")),
                        "default_gateway": _string(values.get("DhcpDefaultGateway")) or _string(values.get("DefaultGateway")),
                        "dns_servers": _string(values.get("DhcpNameServer")) or _string(values.get("NameServer")),
                        "domain": _string(values.get("DhcpDomain")) or _string(values.get("Domain")),
                        "subnet_mask": _string(values.get("DhcpSubnetMask")) or _string(values.get("SubnetMask")),
                        "lease_terminates": unix_time(values.get("LeaseTerminatesTime")),
                    }),
                )
