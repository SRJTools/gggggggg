from __future__ import annotations

import bz2
import gzip
import lzma
import re
import shlex
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator
from urllib.parse import urlsplit

from ..models import Artifact, EvidenceRecord
from ..utils import iso_utc, parse_host_port, url_endpoint
from .base import ExtractorContext, infer_user, local_path, record


SYSLOG_PREFIX = re.compile(r"^(?P<month>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<clock>\d\d:\d\d:\d\d)")
ISO_PREFIX = re.compile(r"^(?P<ts>\d{4}-\d\d-\d\d[T ][0-9:.+-]+Z?)")
SSH_AUTH = re.compile(
    r"(?P<status>Accepted|Failed)\s+(?P<method>password|publickey|keyboard-interactive|none)"
    r"\s+for\s+(?:invalid user\s+)?(?P<user>\S+)\s+from\s+(?P<host>\S+)\s+port\s+(?P<port>\d+)",
    re.I,
)
SSH_CONNECT = re.compile(
    r"(?P<event>Connection from|Disconnected from|Received disconnect from|Connection closed by)\s+"
    r"(?P<host>\S+)(?:\s+port\s+(?P<port>\d+))?",
    re.I,
)
UFW_PAIR = re.compile(r"\b(SRC|DST|SPT|DPT|PROTO|IN|OUT)=([^\s]+)")
AUDIT_ARG = re.compile(r"\ba(\d+)=((?:\"[^\"]*\")|(?:\S+))")
NETWORK_COMMAND = re.compile(
    r"(?i)(?:^|[;&|]\s*)(?:sudo\s+)?(?:ssh|scp|sftp|telnet|ftp|curl|wget|nc|ncat|netcat|"
    r"ping|ping6|traceroute|tracert|nslookup|dig|host|Test-NetConnection|Invoke-WebRequest|"
    r"Invoke-RestMethod|bitsadmin|certutil|rsync|rdesktop|xfreerdp|mstsc|openvpn|wg-quick)\b"
)


def _open_text(path: Path):
    suffix = path.suffix.casefold()
    if suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    if suffix == ".bz2":
        return bz2.open(path, "rt", encoding="utf-8", errors="replace")
    if suffix in {".xz", ".lzma"}:
        return lzma.open(path, "rt", encoding="utf-8", errors="replace")
    return path.open("rt", encoding="utf-8-sig", errors="replace")


def _timestamp_from_line(line: str) -> str | None:
    iso_match = ISO_PREFIX.match(line)
    if iso_match:
        value = iso_match.group("ts").replace(" ", "T")
        return value if value.endswith("Z") else value
    syslog_match = SYSLOG_PREFIX.match(line)
    if syslog_match:
        year = datetime.now(timezone.utc).year
        try:
            parsed = datetime.strptime(
                f"{year} {syslog_match.group(0)}", "%Y %b %d %H:%M:%S"
            ).replace(tzinfo=timezone.utc)
            return iso_utc(parsed)
        except ValueError:
            return None
    return None


def _command_endpoint(command: str) -> tuple[str | None, int | None, str | None, str | None]:
    url_match = re.search(r"(?i)\b(?:https?|ftp)://[^\s'\"]+", command)
    if url_match:
        url = url_match.group(0).rstrip(")],")
        host, port, protocol = url_endpoint(url)
        return host, port, protocol, url
    ssh_match = re.search(
        r"(?i)\b(?P<proto>ssh|sftp|scp|telnet|ftp|rdesktop|xfreerdp)\b"
        r"(?:\s+-\S+(?:\s+\S+)?)?\s+(?P<target>(?:[^\s@]+@)?(?:\[[^]]+\]|[^\s:]+)(?::\d+)?)",
        command,
    )
    if ssh_match:
        target = ssh_match.group("target").rsplit("@", 1)[-1]
        defaults = {"ssh": 22, "sftp": 22, "scp": 22, "telnet": 23, "ftp": 21, "rdesktop": 3389, "xfreerdp": 3389}
        host, port = parse_host_port(target, defaults.get(ssh_match.group("proto").lower()))
        return host, port, ssh_match.group("proto").lower(), None
    utility_match = re.search(
        r"(?i)\b(?P<proto>ping6?|traceroute|tracert|nslookup|dig|host|nc|ncat|netcat|test-netconnection)\b"
        r"(?:\s+-\S+(?:\s+\S+)?)?\s+(?P<host>[^\s;&|]+)",
        command,
    )
    if utility_match:
        return utility_match.group("host").strip("[]"), None, utility_match.group("proto").lower(), None
    return None, None, None, None


class FirewallExtractor:
    name = "firewall"
    categories = frozenset({"firewall"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        fields: list[str] | None = None
        with _open_text(local_path(artifact)) as handle:
            for line_number, raw in enumerate(handle, 1):
                if line_number > context.max_records * 4:
                    break
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("#Fields:"):
                    fields = line.partition(":")[2].strip().split()
                    continue
                if line.startswith("#"):
                    continue
                if fields:
                    values = line.split()
                    if len(values) < len(fields):
                        continue
                    item = dict(zip(fields, values))
                    timestamp = "T".join(filter(None, [item.get("date"), item.get("time")])) or None
                    src, dst = item.get("src-ip"), item.get("dst-ip")
                    yield record(
                        artifact,
                        kind="connection",
                        source="windows_firewall_log",
                        event=item.get("action", "traffic").lower(),
                        timestamp=f"{timestamp}Z" if timestamp and not timestamp.endswith("Z") else timestamp,
                        os="windows",
                        protocol=item.get("protocol"),
                        local_address=src,
                        local_port=item.get("src-port"),
                        remote_address=dst,
                        remote_port=item.get("dst-port"),
                        direction="unknown",
                        status=item.get("action"),
                        confidence="high",
                        evidence_offset=line_number,
                        details=context.redactor.mapping(item),
                    )
                    continue
                pairs = dict(UFW_PAIR.findall(line))
                if "SRC" in pairs and "DST" in pairs:
                    status_match = re.search(r"\[(UFW [^]]+)\]", line)
                    status = status_match.group(1) if status_match else "firewall"
                    yield record(
                        artifact,
                        kind="connection",
                        source="linux_firewall_log",
                        event=status.lower().replace(" ", "_"),
                        timestamp=_timestamp_from_line(line),
                        os="linux",
                        protocol=pairs.get("PROTO", "").lower() or None,
                        local_address=pairs.get("SRC"),
                        local_port=pairs.get("SPT"),
                        remote_address=pairs.get("DST"),
                        remote_port=pairs.get("DPT"),
                        direction="unknown",
                        status=status,
                        confidence="high",
                        evidence_offset=line_number,
                        details=context.redactor.mapping(pairs),
                    )


class LinuxLogExtractor:
    name = "linux_logs"
    categories = frozenset({"linux_log", "audit"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        emitted = 0
        with _open_text(local_path(artifact)) as handle:
            for line_number, raw in enumerate(handle, 1):
                if emitted >= context.max_records:
                    break
                line = raw.strip()
                auth = SSH_AUTH.search(line)
                if auth:
                    emitted += 1
                    yield record(
                        artifact,
                        kind="connection",
                        source="openssh_log",
                        event="ssh_authentication",
                        timestamp=_timestamp_from_line(line),
                        os="linux",
                        user=auth.group("user"),
                        application="sshd",
                        protocol="ssh",
                        remote_address=auth.group("host"),
                        remote_port=int(auth.group("port")),
                        direction="inbound",
                        status=auth.group("status").lower(),
                        confidence="high",
                        evidence_offset=line_number,
                        details={"method": auth.group("method")},
                    )
                    continue
                connection = SSH_CONNECT.search(line)
                if connection:
                    emitted += 1
                    yield record(
                        artifact,
                        kind="connection",
                        source="openssh_log",
                        event=connection.group("event").lower().replace(" ", "_"),
                        timestamp=_timestamp_from_line(line),
                        os="linux",
                        application="sshd",
                        protocol="ssh",
                        remote_address=connection.group("host"),
                        remote_port=int(connection.group("port")) if connection.group("port") else None,
                        direction="inbound",
                        status="observed",
                        confidence="high",
                        evidence_offset=line_number,
                    )
                    continue
                if artifact.category == "audit" and "type=EXECVE" in line:
                    args = [match.group(2).strip('"') for match in AUDIT_ARG.finditer(line)]
                    command = " ".join(args)
                    if command and (context.include_all_commands or NETWORK_COMMAND.search(command)):
                        emitted += 1
                        yield record(
                            artifact,
                            kind="command",
                            source="linux_audit",
                            event="execve",
                            timestamp=None,
                            os="linux",
                            command=context.redactor.text(command),
                            confidence="high",
                            evidence_offset=line_number,
                        )


def _history_commands(path: Path) -> Iterator[tuple[str | None, str]]:
    pending_time: str | None = None
    with _open_text(path) as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if not line:
                continue
            if re.fullmatch(r"#\d{9,}", line):
                pending_time = iso_utc(datetime.fromtimestamp(int(line[1:]), tz=timezone.utc))
                continue
            zsh = re.match(r"^:\s*(\d+):\d+;(.*)$", line)
            if zsh:
                timestamp = iso_utc(datetime.fromtimestamp(int(zsh.group(1)), tz=timezone.utc))
                yield timestamp, zsh.group(2)
                continue
            fish = re.match(r"^\s*-\s*cmd:\s*(.*)$", line)
            if fish:
                yield pending_time, fish.group(1)
                pending_time = None
                continue
            yield pending_time, line
            pending_time = None


class ShellHistoryExtractor:
    name = "shell_history"
    categories = frozenset({"shell_history"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        user = infer_user(artifact.evidence_path)
        for index, (timestamp, command) in enumerate(_history_commands(local_path(artifact)), 1):
            if index > context.max_records:
                break
            is_network = bool(NETWORK_COMMAND.search(command))
            clean_command = context.redactor.text(command)
            if context.include_all_commands:
                yield record(
                    artifact,
                    kind="command",
                    source="shell_history",
                    event="network_command" if is_network else "command",
                    timestamp=timestamp,
                    user=user,
                    command=clean_command,
                    confidence="high",
                    evidence_offset=index,
                )
            if is_network:
                host, port, protocol, url = _command_endpoint(command)
                yield record(
                    artifact,
                    kind="connection",
                    source="shell_history",
                    event="network_command",
                    timestamp=timestamp,
                    user=user,
                    protocol=protocol,
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    command=clean_command,
                    url=context.redactor.url(url),
                    confidence="medium",
                    evidence_offset=index,
                )

