from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

from ..models import Artifact, EvidenceRecord
from ..utils import parse_host_port
from .base import ExtractorContext, local_path, record
from .text import _open_text, _timestamp_from_line


IPV4 = r"(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}"
ENDPOINT = re.compile(rf"(?<![\w.])(?P<host>{IPV4}|[A-Za-z0-9][A-Za-z0-9.-]+\.[A-Za-z]{{2,}})(?::(?P<port>\d{{1,5}}))?")
REMOTE_HINT = re.compile(
    r"(?i)\b(connect(?:ed|ing|ion)?|session|partner|relay|router|tcp|udp|proxy|remote|client)\b"
)
COMMON_LOG = re.compile(
    r'^(?P<host>\S+)\s+\S+\s+(?P<user>\S+)\s+\[(?P<time>[^]]+)]\s+'
    r'"(?P<method>\S+)\s+(?P<uri>\S+)(?:\s+HTTP/[^\"]+)?"\s+(?P<status>\d{3}|-)\s+(?P<bytes>\d+|-)'
)
CLIENT_ENDPOINT = re.compile(
    r"(?i)(?:connecting\s+to|connected\s+to|looking\s+up\s+host|host\s+name\s+is|last\s+login:.*?\s+from)"
    r"\s+[\"']?(?P<host>\[[0-9a-f:]+\]|[A-Za-z0-9_.:-]+)[\"']?(?:\s+(?:port\s+)?(?P<port>\d{1,5}))?"
)


def _is_noise(host: str) -> bool:
    lowered = host.casefold()
    return lowered in {"0.0.0.0", "127.0.0.1", "localhost"} or lowered.endswith(
        (".dll", ".exe", ".log", ".trace")
    )


class RemoteSupportLogExtractor:
    """Best-effort parser for AnyDesk/TeamViewer-style connection traces."""

    name = "remote_support_logs"
    categories = frozenset({"remote_support_log"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        emitted = 0
        application = "AnyDesk" if "anydesk" in artifact.evidence_path.casefold() else "TeamViewer"
        with _open_text(local_path(artifact)) as handle:
            for line_number, raw in enumerate(handle, 1):
                if emitted >= context.max_records:
                    break
                line = raw.strip()
                if not line or not REMOTE_HINT.search(line):
                    continue
                seen: set[tuple[str, int | None]] = set()
                for match in ENDPOINT.finditer(line):
                    host = match.group("host")
                    port = int(match.group("port")) if match.group("port") else None
                    if _is_noise(host) or (host, port) in seen:
                        continue
                    seen.add((host, port))
                    emitted += 1
                    yield record(
                        artifact,
                        kind="connection",
                        source="remote_support_log",
                        event="remote_support_endpoint",
                        timestamp=_timestamp_from_line(line),
                        application=application,
                        protocol="remote_support",
                        remote_address=host,
                        remote_port=port,
                        direction="unknown",
                        status="observed",
                        confidence="medium",
                        evidence_offset=line_number,
                        details={"line": context.redactor.text(line[:2000])},
                    )
                    if emitted >= context.max_records:
                        break


class ClientSessionLogExtractor:
    """Extract endpoints recorded in PuTTY, WinSCP, and FileZilla text logs."""

    name = "client_session_logs"
    categories = frozenset({"client_log"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        lowered = artifact.evidence_path.casefold()
        application = "PuTTY" if "putty" in lowered else "WinSCP" if "winscp" in lowered else "FileZilla"
        emitted = 0
        with _open_text(local_path(artifact)) as handle:
            for line_number, raw in enumerate(handle, 1):
                if emitted >= context.max_records:
                    break
                line = raw.strip()
                match = CLIENT_ENDPOINT.search(line)
                if not match:
                    continue
                host, parsed_port = parse_host_port(match.group("host").strip("[]"))
                port = int(match.group("port")) if match.group("port") else parsed_port
                emitted += 1
                yield record(
                    artifact,
                    kind="connection",
                    source="client_session_log",
                    event="client_endpoint",
                    timestamp=_timestamp_from_line(line),
                    application=application,
                    protocol="ssh" if application in {"PuTTY", "WinSCP"} else "ftp/sftp",
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    status="observed",
                    confidence="medium",
                    evidence_offset=line_number,
                    details={"line": context.redactor.text(line[:2000])},
                )


class WebAccessLogExtractor:
    name = "web_access_logs"
    categories = frozenset({"web_access_log"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        fields: list[str] | None = None
        emitted = 0
        with _open_text(local_path(artifact)) as handle:
            for line_number, raw in enumerate(handle, 1):
                if emitted >= context.max_records:
                    break
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("#Fields:"):
                    fields = line.partition(":")[2].strip().split()
                    continue
                if line.startswith("#"):
                    continue
                if fields:
                    values = line.split()
                    if len(values) < len(fields):
                        continue
                    item = dict(zip(fields, values))
                    remote = item.get("c-ip")
                    if not remote:
                        continue
                    emitted += 1
                    timestamp = "T".join(
                        value for value in (item.get("date"), item.get("time")) if value
                    )
                    yield record(
                        artifact,
                        kind="connection",
                        source="iis_access_log",
                        event="http_request",
                        timestamp=f"{timestamp}Z" if timestamp and not timestamp.endswith("Z") else timestamp,
                        application="IIS",
                        protocol="https" if item.get("s-port") == "443" else "http",
                        local_address=item.get("s-ip"),
                        local_port=item.get("s-port"),
                        remote_address=remote,
                        direction="inbound",
                        status=item.get("sc-status"),
                        bytes_sent=int(item["sc-bytes"]) if item.get("sc-bytes", "").isdigit() else None,
                        bytes_received=int(item["cs-bytes"]) if item.get("cs-bytes", "").isdigit() else None,
                        confidence="high",
                        evidence_offset=line_number,
                        details=context.redactor.mapping(item),
                    )
                    continue
                match = COMMON_LOG.match(line)
                if not match:
                    continue
                item = match.groupdict()
                host, _ = parse_host_port(item["host"])
                emitted += 1
                yield record(
                    artifact,
                    kind="connection",
                    source="web_access_log",
                    event="http_request",
                    timestamp=item.get("time"),
                    application="Apache/Nginx",
                    protocol="http",
                    remote_address=host,
                    direction="inbound",
                    status=item.get("status"),
                    bytes_sent=int(item["bytes"]) if item.get("bytes", "").isdigit() else None,
                    user=None if item.get("user") == "-" else item.get("user"),
                    confidence="high",
                    evidence_offset=line_number,
                    details=context.redactor.mapping(item),
                )
