from __future__ import annotations

import base64
import configparser
import hashlib
import re
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Iterable

from ..models import Artifact, EvidenceRecord
from ..utils import parse_host_port
from .base import ExtractorContext, infer_user, local_path, record
from .text import NETWORK_COMMAND, _command_endpoint


def _fingerprint(key_data: str) -> str | None:
    try:
        digest = hashlib.sha256(base64.b64decode(key_data.encode(), validate=True)).digest()
        return "SHA256:" + base64.b64encode(digest).decode().rstrip("=")
    except Exception:
        return None


class OpenSSHExtractor:
    name = "openssh_config"
    categories = frozenset({"openssh"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        path = local_path(artifact)
        user = infer_user(artifact.evidence_path)
        if "known_hosts" in path.name.casefold():
            text = path.read_text("utf-8", errors="replace")
            for line_number, line in enumerate(text.splitlines(), 1):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                marker = parts.pop(0) if parts and parts[0].startswith("@") else None
                if len(parts) < 2:
                    continue
                hosts, key_type = parts[0], parts[1]
                fingerprint = _fingerprint(parts[2]) if len(parts) > 2 else None
                for host_value in hosts.split(","):
                    host, port = parse_host_port(host_value, 22)
                    yield record(
                        artifact,
                        kind="configuration",
                        source="openssh_known_hosts",
                        event="ssh_known_host",
                        user=user,
                        protocol="ssh",
                        remote_address=host,
                        remote_port=port,
                        direction="outbound",
                        confidence="high",
                        evidence_offset=line_number,
                        details={"key_type": key_type, "fingerprint": fingerprint, "marker": marker},
                    )
            return
        current: dict[str, str] = {}
        text = path.read_text("utf-8", errors="replace")
        for line_number, raw in enumerate(text.splitlines() + ["Host __end__"], 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            key, _, value = line.partition(" ")
            if key.casefold() in {"host", "match"}:
                if current:
                    host = current.get("hostname") or current.get("host")
                    if host and not any(ch in host for ch in "*?!"):
                        yield record(
                            artifact,
                            kind="configuration",
                            source="openssh_config",
                            event="ssh_host_config",
                            user=current.get("user") or user,
                            protocol="ssh",
                            remote_address=host,
                            remote_port=int(current.get("port", "22")) if current.get("port", "22").isdigit() else current.get("port"),
                            direction="outbound",
                            confidence="high",
                            evidence_offset=current.get("_line"),
                            details=context.redactor.mapping({k: v for k, v in current.items() if k not in {"_line"}}),
                        )
                current = {"host": value.strip(), "_line": str(line_number)}
            elif current:
                current[key.casefold()] = value.strip()


class PuttyLinuxExtractor:
    name = "putty_linux"
    categories = frozenset({"putty_linux"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        values: dict[str, str] = {}
        for line in local_path(artifact).read_text("utf-8", errors="replace").splitlines():
            key, separator, value = line.partition("\\")
            if separator:
                values[key] = value
        host = values.get("HostName")
        if not host:
            return
        yield record(
            artifact,
            kind="configuration",
            source="putty_session",
            event="saved_session",
            user=values.get("UserName") or infer_user(artifact.evidence_path),
            application="PuTTY",
            protocol=values.get("Protocol", "ssh"),
            remote_address=host,
            remote_port=int(values.get("PortNumber", "22")) if values.get("PortNumber", "22").isdigit() else values.get("PortNumber"),
            direction="outbound",
            confidence="high",
            details=context.redactor.mapping({
                "session": urllib.parse.unquote(local_path(artifact).name),
                "proxy_host": values.get("ProxyHost"),
                "proxy_port": values.get("ProxyPort"),
                "log_file": values.get("LogFileName"),
            }),
        )


class RdpExtractor:
    name = "rdp_files"
    categories = frozenset({"rdp"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        values: dict[str, str] = {}
        text = local_path(artifact).read_text("utf-8-sig", errors="replace")
        for line in text.splitlines():
            parts = line.split(":", 2)
            if len(parts) == 3:
                values[parts[0].casefold()] = parts[2]
        endpoint = values.get("full address")
        if not endpoint:
            return
        host, port = parse_host_port(endpoint, 3389)
        yield record(
            artifact,
            kind="configuration",
            source="rdp_file",
            event="saved_rdp_connection",
            user=values.get("username") or infer_user(artifact.evidence_path),
            application="Remote Desktop",
            protocol="rdp",
            remote_address=host,
            remote_port=port,
            direction="outbound",
            confidence="high",
            details=context.redactor.mapping({
                "gateway": values.get("gatewayhostname"),
                "alternate_shell": values.get("alternate shell"),
                "prompt_for_credentials": values.get("prompt for credentials"),
            }),
        )


class XmlConnectionExtractor:
    name = "xml_connections"
    categories = frozenset({"wlan_xml", "filezilla", "mremoteng"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        root = ET.parse(local_path(artifact)).getroot()
        category = artifact.category
        if category == "wlan_xml":
            values = {element.tag.split("}")[-1]: (element.text or "") for element in root.iter()}
            ssid = values.get("name") or values.get("hex")
            yield record(
                artifact,
                kind="configuration",
                source="windows_wlan_profile",
                event="saved_wifi_profile",
                os="windows",
                protocol="wifi",
                remote_address=ssid,
                confidence="high",
                details=context.redactor.mapping(values),
            )
            return
        if category == "filezilla":
            for server in root.findall(".//Server"):
                values = {child.tag: (child.text or "") for child in server}
                host = values.get("Host")
                if host:
                    yield record(
                        artifact,
                        kind="configuration",
                        source="filezilla",
                        event="saved_server",
                        user=values.get("User") or infer_user(artifact.evidence_path),
                        application="FileZilla",
                        protocol=values.get("Protocol") or "ftp/sftp",
                        remote_address=host,
                        remote_port=int(values["Port"]) if values.get("Port", "").isdigit() else values.get("Port"),
                        direction="outbound",
                        confidence="high",
                        details=context.redactor.mapping(values),
                    )
            return
        for node in root.iter():
            values = {key.casefold(): value for key, value in node.attrib.items()}
            host = values.get("hostname") or values.get("host")
            if host:
                yield record(
                    artifact,
                    kind="configuration",
                    source="mremoteng",
                    event="saved_connection",
                    user=values.get("username") or infer_user(artifact.evidence_path),
                    application="mRemoteNG",
                    protocol=values.get("protocol"),
                    remote_address=host,
                    remote_port=int(values["port"]) if values.get("port", "").isdigit() else values.get("port"),
                    direction="outbound",
                    confidence="high",
                    details=context.redactor.mapping(values),
                )


class NetworkConfigExtractor:
    name = "network_config"
    categories = frozenset({"network_config", "networkmanager", "vpn_config", "dhcp_lease"})

    ENDPOINT_RE = re.compile(r"(?i)^\s*(remote|endpoint|server|gateway|address|dns|phonenumber)\s*[=: ]\s*(\S+)")

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        text = local_path(artifact).read_text("utf-8-sig", errors="replace")
        emitted = False
        if artifact.category == "vpn_config" and text.lstrip().startswith("<"):
            try:
                root = ET.fromstring(text)
                for line_number, node in enumerate(root.iter(), 1):
                    tag = node.tag.rsplit("}", 1)[-1].casefold()
                    value = (node.text or "").strip()
                    if tag not in {"hostaddress", "hostname", "server", "backupserver", "fqdn"} or not value:
                        continue
                    host, port = parse_host_port(value)
                    emitted = True
                    yield record(
                        artifact,
                        kind="configuration",
                        source="vpn_config",
                        event=f"configured_{tag}",
                        user=infer_user(artifact.evidence_path),
                        protocol="vpn",
                        remote_address=host,
                        remote_port=port,
                        direction="outbound",
                        confidence="high",
                        evidence_offset=line_number,
                    )
            except ET.ParseError:
                pass
        for line_number, line in enumerate(text.splitlines(), 1):
            match = self.ENDPOINT_RE.match(line)
            if not match:
                continue
            key, value = match.groups()
            if key.casefold() == "address" and "/" in value:
                continue
            host, port = parse_host_port(value)
            emitted = True
            yield record(
                artifact,
                kind="configuration",
                source=artifact.category,
                event=f"configured_{key.lower()}",
                user=infer_user(artifact.evidence_path),
                protocol="vpn" if artifact.category == "vpn_config" else None,
                remote_address=host,
                remote_port=port,
                direction="outbound" if artifact.category == "vpn_config" else None,
                confidence="medium",
                evidence_offset=line_number,
                details={"line": context.redactor.text(line.strip())},
            )
        if not emitted and artifact.category in {"networkmanager", "network_config"}:
            clean: dict[str, str] = {}
            section = "global"
            for raw in text.splitlines():
                line = raw.strip()
                if not line or line.startswith(("#", ";")):
                    continue
                if line.startswith("[") and line.endswith("]"):
                    section = line[1:-1]
                    continue
                key, sep, value = line.partition("=")
                if sep:
                    clean[f"{section}.{key.strip()}"] = value.strip()
            if clean:
                yield record(
                    artifact,
                    kind="configuration",
                    source=artifact.category,
                    event="network_configuration",
                    user=infer_user(artifact.evidence_path),
                    confidence="medium",
                    details=context.redactor.mapping(clean),
                )


class ScheduledTaskExtractor:
    name = "windows_scheduled_tasks"
    categories = frozenset({"scheduled_task"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        try:
            root = ET.parse(local_path(artifact)).getroot()
        except ET.ParseError:
            return
        values: dict[str, list[str]] = {}
        for node in root.iter():
            tag = node.tag.rsplit("}", 1)[-1]
            text = (node.text or "").strip()
            if text:
                values.setdefault(tag, []).append(text)
        commands = values.get("Command", [])
        arguments = values.get("Arguments", [])
        for index, executable in enumerate(commands):
            argument = arguments[index] if index < len(arguments) else ""
            command = f"{executable} {argument}".strip()
            is_network = bool(NETWORK_COMMAND.search(command) or re.search(r"(?i)(?:https?|ftp)://|\\\\[^\\\s]+", command))
            if not context.include_all_commands and not is_network:
                continue
            clean_command = context.redactor.text(command)
            yield record(
                artifact,
                kind="command",
                source="scheduled_task",
                event="network_task_action" if is_network else "task_action",
                os="windows",
                user=(values.get("UserId") or values.get("Author") or [None])[0],
                application=executable,
                command=clean_command,
                confidence="high",
                evidence_offset=index + 1,
                details={
                    "task_uri": (values.get("URI") or [None])[0],
                    "author": (values.get("Author") or [None])[0],
                    "working_directory": (values.get("WorkingDirectory") or [None])[0],
                },
            )
            if is_network:
                host, port, protocol, url = _command_endpoint(command)
                if not host:
                    unc = re.search(r"\\\\(?P<host>[^\\\s]+)", command)
                    if unc:
                        host, port, protocol = unc.group("host"), 445, "smb"
                yield record(
                    artifact,
                    kind="connection",
                    source="scheduled_task",
                    event="network_task_action",
                    os="windows",
                    user=(values.get("UserId") or values.get("Author") or [None])[0],
                    application=executable,
                    protocol=protocol,
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    command=clean_command,
                    url=context.redactor.url(url),
                    confidence="medium",
                    evidence_offset=index + 1,
                )
