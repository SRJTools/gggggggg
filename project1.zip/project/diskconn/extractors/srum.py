from __future__ import annotations

import csv
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Iterator

from ..models import Artifact, EvidenceRecord
from ..utils import first, iso_utc, windows_filetime
from .base import ExtractorContext, record


SRUM_TABLES = {
    "d10ca2fe-6fcf-4f6d-848e-b2e99266fa89": "network_data_usage",
    "dd6636c4-8929-4683-974e-22c046a43763": "network_connectivity",
    "973f5d5c-1d90-4944-be8e-24b94231a174": "application_resource_usage",
}


def _call_or_attr(obj: Any, *names: str) -> Any:
    for name in names:
        if hasattr(obj, name):
            value = getattr(obj, name)
            return value() if callable(value) else value
    raise AttributeError(f"None of {names!r} exists on {type(obj).__name__}")


def _decode_blob(value: Any) -> Any:
    if not isinstance(value, (bytes, bytearray)):
        return value
    raw = bytes(value)
    if len(raw) >= 8 and raw[0] == 1 and raw[1] <= 15:
        try:
            count = raw[1]
            authority = int.from_bytes(raw[2:8], "big")
            parts = [str(int.from_bytes(raw[8 + index * 4:12 + index * 4], "little")) for index in range(count)]
            return "S-1-" + str(authority) + "-" + "-".join(parts)
        except Exception:
            pass
    for encoding in ("utf-16-le", "utf-8"):
        try:
            text = raw.decode(encoding).rstrip("\x00")
            if text and sum(ch.isprintable() for ch in text) / len(text) > 0.8:
                return text
        except (UnicodeDecodeError, ZeroDivisionError):
            pass
    return raw.hex()


def _value_data(value: Any) -> Any:
    for name in ("data", "value", "get_data", "get_value_data"):
        if hasattr(value, name):
            item = getattr(value, name)
            try:
                return _decode_blob(item() if callable(item) else item)
            except Exception:
                pass
    return None


def _pyesedb_rows(path: Path) -> Iterator[tuple[str, dict[str, Any]]]:
    import pyesedb  # type: ignore

    database = pyesedb.file()
    database.open(str(path))
    try:
        table_count = int(_call_or_attr(database, "number_of_tables", "get_number_of_tables"))
        for table_index in range(table_count):
            table = database.get_table(table_index)
            table_name = str(_call_or_attr(table, "name", "get_name"))
            record_count = int(_call_or_attr(table, "number_of_records", "get_number_of_records"))
            for row_index in range(record_count):
                row = table.get_record(row_index)
                value_count = int(_call_or_attr(row, "number_of_values", "get_number_of_values"))
                values: dict[str, Any] = {}
                for value_index in range(value_count):
                    value = row.get_value(value_index)
                    name = str(_call_or_attr(value, "name", "get_name"))
                    values[name] = _value_data(value)
                values["_record_index"] = row_index
                yield table_name, values
    finally:
        database.close()


def _external_rows(path: Path) -> Iterator[tuple[str, dict[str, Any]]]:
    executable = shutil.which("esedbexport")
    if not executable:
        raise RuntimeError("SRUM parsing requires pyesedb or the esedbexport utility")
    with tempfile.TemporaryDirectory(prefix="diskconn-srum-") as temporary:
        target = Path(temporary) / "srum"
        subprocess.run([executable, "-t", str(target), str(path)], check=True, capture_output=True, text=True)
        files = [item for item in Path(temporary).rglob("*") if item.is_file()]
        for table_file in files:
            try:
                with table_file.open("r", encoding="utf-8", errors="replace", newline="") as handle:
                    sample = handle.read(4096)
                    handle.seek(0)
                    delimiter = "\t" if sample.count("\t") >= sample.count(",") else ","
                    reader = csv.DictReader(handle, delimiter=delimiter)
                    if not reader.fieldnames:
                        continue
                    for index, row in enumerate(reader):
                        row["_record_index"] = index
                        yield table_file.stem, dict(row)
            except (OSError, csv.Error):
                continue


def _rows(path: Path) -> Iterator[tuple[str, dict[str, Any]]]:
    try:
        import pyesedb  # noqa: F401
    except ImportError:
        yield from _external_rows(path)
    else:
        yield from _pyesedb_rows(path)


def _timestamp(value: Any) -> str | None:
    if isinstance(value, datetime):
        return iso_utc(value)
    if isinstance(value, str) and any(char in value for char in "-T:"):
        return value
    return windows_filetime(value)


class SrumExtractor:
    name = "srum"
    categories = frozenset({"srum"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        all_rows = list(_rows(Path(artifact.local_path)))
        id_map: dict[str, Any] = {}
        for table_name, row in all_rows:
            if "idmap" not in table_name.casefold():
                continue
            index = first(row, ("IdIndex", "Id", "Index"))
            blob = first(row, ("IdBlob", "Blob", "Value"))
            if index is not None:
                id_map[str(index)] = _decode_blob(blob)
        emitted = 0
        for table_name, row in all_rows:
            lowered_name = table_name.casefold().strip("{}")
            table_event = next((event for guid, event in SRUM_TABLES.items() if guid in lowered_name), None)
            columns = {key.casefold() for key in row}
            if table_event is None:
                if {"bytessent", "bytesrecvd"} & columns:
                    table_event = "network_data_usage"
                elif {"connectedtime", "connectstarttime", "l2profileid"} & columns:
                    table_event = "network_connectivity"
            if table_event not in {"network_data_usage", "network_connectivity"}:
                continue
            if emitted >= context.max_records:
                break
            emitted += 1
            app_id = first(row, ("AppId", "ApplicationId"))
            user_id = first(row, ("UserId",))
            profile_id = first(row, ("L2ProfileId", "ProfileId"))
            app = id_map.get(str(app_id), app_id)
            user = id_map.get(str(user_id), user_id)
            profile = id_map.get(str(profile_id), profile_id)
            sent = first(row, ("BytesSent", "BytesSentForeground", "BytesSentBackground"))
            received = first(row, ("BytesRecvd", "BytesReceived", "BytesRecvdForeground", "BytesRecvdBackground"))
            timestamp = _timestamp(first(row, ("TimeStamp", "ConnectStartTime")))
            yield record(
                artifact,
                kind="connection",
                source="srum",
                event=table_event,
                timestamp=timestamp,
                os="windows",
                user=str(user) if user is not None else None,
                application=str(app) if app is not None else None,
                protocol="network_usage",
                status="observed",
                bytes_sent=int(sent) if str(sent).isdigit() else None,
                bytes_received=int(received) if str(received).isdigit() else None,
                confidence="high",
                evidence_offset=first(row, ("AutoIncId", "_record_index")),
                details=context.redactor.mapping({
                    "table": table_name,
                    "interface_luid": first(row, ("InterfaceLuid",)),
                    "profile_id": profile,
                    "connected_time_seconds": first(row, ("ConnectedTime",)),
                    "connect_start_time": _timestamp(first(row, ("ConnectStartTime",))),
                    "note": "SRUM reports application/network usage but normally does not store remote IP addresses.",
                }),
            )

