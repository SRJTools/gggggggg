from __future__ import annotations

import json
import re
import shutil
import subprocess
from typing import Iterable

from ..models import Artifact, EvidenceRecord
from .base import ExtractorContext, record
from .text import SSH_AUTH, SSH_CONNECT


class LoginRecordExtractor:
    name = "login_records"
    categories = frozenset({"login_records"})
    FIELD = re.compile(r"\[([^]]*)\]")

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        executable = shutil.which("utmpdump")
        if not executable:
            raise RuntimeError("utmpdump is required to parse wtmp/btmp records")
        result = subprocess.run([executable, artifact.local_path], check=True, capture_output=True, text=True, errors="replace")
        for index, line in enumerate(result.stdout.splitlines(), 1):
            if index > context.max_records:
                break
            fields = self.FIELD.findall(line)
            if len(fields) < 8:
                continue
            record_type, _, terminal, user, _, host, address, timestamp = fields[:8]
            if record_type.strip() not in {"7", "8"} or not (host.strip() or address.strip()):
                continue
            yield record(
                artifact,
                kind="connection",
                source="utmp_record",
                event="user_login" if record_type.strip() == "7" else "user_logout",
                timestamp=timestamp.strip() or None,
                os="linux",
                user=user.strip() or None,
                remote_address=address.strip() or host.strip(),
                direction="inbound",
                status="observed",
                confidence="high",
                evidence_offset=index,
                details={"terminal": terminal.strip(), "host": host.strip()},
            )


class JournalExtractor:
    name = "systemd_journal"
    categories = frozenset({"journal"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        executable = shutil.which("journalctl")
        if not executable:
            raise RuntimeError("journalctl is required to parse systemd journal files")
        result = subprocess.run(
            [executable, f"--file={artifact.local_path}", "--output=json", "--all", "--no-pager"],
            check=True, capture_output=True, text=True, errors="replace",
        )
        emitted = 0
        for line_number, line in enumerate(result.stdout.splitlines(), 1):
            if emitted >= context.max_records:
                break
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            message = str(item.get("MESSAGE", ""))
            match = SSH_AUTH.search(message) or SSH_CONNECT.search(message)
            if not match:
                continue
            emitted += 1
            groups = match.groupdict()
            micros = item.get("__REALTIME_TIMESTAMP")
            timestamp = None
            if str(micros).isdigit():
                from ..utils import unix_time
                timestamp = unix_time(micros, microseconds=True)
            yield record(
                artifact,
                kind="connection",
                source="systemd_journal",
                event="ssh_event",
                timestamp=timestamp,
                os="linux",
                user=groups.get("user"),
                application=str(item.get("SYSLOG_IDENTIFIER", "sshd")),
                protocol="ssh",
                remote_address=groups.get("host"),
                remote_port=int(groups["port"]) if groups.get("port") else None,
                direction="inbound",
                status=(groups.get("status") or groups.get("event") or "observed").lower(),
                confidence="high",
                evidence_offset=line_number,
            )

