from .browser import BrowserHistoryExtractor
from .config import (
    NetworkConfigExtractor,
    OpenSSHExtractor,
    PuttyLinuxExtractor,
    RdpExtractor,
    ScheduledTaskExtractor,
    XmlConnectionExtractor,
)
from .evtx import EvtxExtractor
from .external import JournalExtractor, LoginRecordExtractor
from .registry import RegistryExtractor
from .service_logs import ClientSessionLogExtractor, RemoteSupportLogExtractor, WebAccessLogExtractor
from .srum import SrumExtractor
from .text import FirewallExtractor, LinuxLogExtractor, ShellHistoryExtractor


def default_extractors():
    return [
        RegistryExtractor(),
        EvtxExtractor(),
        SrumExtractor(),
        BrowserHistoryExtractor(),
        FirewallExtractor(),
        LinuxLogExtractor(),
        ShellHistoryExtractor(),
        OpenSSHExtractor(),
        PuttyLinuxExtractor(),
        RdpExtractor(),
        XmlConnectionExtractor(),
        NetworkConfigExtractor(),
        ScheduledTaskExtractor(),
        LoginRecordExtractor(),
        JournalExtractor(),
        RemoteSupportLogExtractor(),
        ClientSessionLogExtractor(),
        WebAccessLogExtractor(),
    ]


__all__ = ["default_extractors"]
