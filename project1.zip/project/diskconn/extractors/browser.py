from __future__ import annotations

import sqlite3
import shutil
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterable

from ..models import Artifact, EvidenceRecord
from ..utils import chrome_time, unix_time, url_endpoint
from .base import ExtractorContext, infer_user, local_path, record


@contextmanager
def _working_sqlite(path: Path):
    """Open a disposable database copy so WAL recovery never changes evidence copies."""
    with tempfile.TemporaryDirectory(prefix="diskconn-sqlite-") as temporary:
        working = Path(temporary) / path.name
        shutil.copy2(path, working)
        for suffix in ("-wal", "-shm", "-journal"):
            sidecar = path.with_name(path.name + suffix)
            if sidecar.is_file():
                shutil.copy2(sidecar, working.with_name(working.name + suffix))
        connection = sqlite3.connect(str(working))
        connection.row_factory = sqlite3.Row
        try:
            yield connection
        finally:
            connection.close()


class BrowserHistoryExtractor:
    name = "browser_history"
    categories = frozenset({"browser_chrome", "browser_firefox", "browser_safari"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        path = local_path(artifact)
        user = infer_user(artifact.evidence_path)
        with _working_sqlite(path) as database:
            if artifact.category == "browser_chrome":
                query = """
                    SELECT urls.url AS url, urls.title AS title, urls.visit_count AS visit_count,
                           urls.typed_count AS typed_count, visits.visit_time AS event_time,
                           visits.transition AS transition, visits.id AS record_id
                    FROM visits JOIN urls ON visits.url = urls.id
                    ORDER BY visits.visit_time DESC LIMIT ?
                """
                rows = database.execute(query, (context.max_records,))
                browser = "Chromium"
            elif artifact.category == "browser_firefox":
                query = """
                    SELECT p.url AS url, p.title AS title, p.visit_count AS visit_count,
                           v.visit_date AS event_time, v.visit_type AS transition,
                           v.id AS record_id
                    FROM moz_historyvisits v JOIN moz_places p ON v.place_id = p.id
                    ORDER BY v.visit_date DESC LIMIT ?
                """
                rows = database.execute(query, (context.max_records,))
                browser = "Firefox"
            else:
                query = """
                    SELECT i.url AS url, i.title AS title,
                           v.visit_time AS event_time, v.id AS record_id,
                           NULL AS visit_count, NULL AS transition
                    FROM history_visits v JOIN history_items i ON v.history_item = i.id
                    ORDER BY v.visit_time DESC LIMIT ?
                """
                rows = database.execute(query, (context.max_records,))
                browser = "Safari"
            for row in rows:
                raw_url = row["url"] or ""
                host, port, protocol = url_endpoint(raw_url)
                if not host:
                    continue
                if artifact.category == "browser_chrome":
                    timestamp = chrome_time(row["event_time"])
                elif artifact.category == "browser_firefox":
                    timestamp = unix_time(row["event_time"], microseconds=True)
                else:
                    # Safari stores seconds since the macOS absolute-time epoch.
                    timestamp = unix_time(float(row["event_time"] or 0) + 978_307_200)
                yield record(
                    artifact,
                    kind="connection",
                    source="browser_history",
                    event="url_visit",
                    timestamp=timestamp,
                    user=user,
                    application=browser,
                    protocol=protocol,
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    status="visited",
                    url=context.redactor.url(raw_url),
                    confidence="high",
                    evidence_offset=int(row["record_id"]),
                    details={
                        "title": row["title"],
                        "visit_count": row["visit_count"],
                        "transition": row["transition"],
                    },
                )

            if artifact.category != "browser_chrome":
                return
            tables = {
                row[0] for row in database.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if not {"downloads", "downloads_url_chains"}.issubset(tables):
                return
            download_query = """
                SELECT d.id AS record_id, d.start_time AS event_time,
                       d.target_path AS target_path, d.received_bytes AS received_bytes,
                       d.total_bytes AS total_bytes, d.state AS state, u.url AS url
                FROM downloads d
                JOIN downloads_url_chains u ON u.id = d.id AND u.chain_index = 0
                ORDER BY d.start_time DESC LIMIT ?
            """
            for row in database.execute(download_query, (context.max_records,)):
                raw_url = row["url"] or ""
                host, port, protocol = url_endpoint(raw_url)
                if not host:
                    continue
                yield record(
                    artifact,
                    kind="connection",
                    source="browser_downloads",
                    event="url_download",
                    timestamp=chrome_time(row["event_time"]),
                    user=user,
                    application="Chromium",
                    protocol=protocol,
                    remote_address=host,
                    remote_port=port,
                    direction="outbound",
                    status=str(row["state"]),
                    bytes_received=int(row["received_bytes"] or 0),
                    url=context.redactor.url(raw_url),
                    confidence="high",
                    evidence_offset=int(row["record_id"]),
                    details={
                        "target_path": context.redactor.text(row["target_path"]),
                        "total_bytes": row["total_bytes"],
                    },
                )
