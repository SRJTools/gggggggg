from __future__ import annotations

import ipaddress
import re
import xml.etree.ElementTree as ET
from typing import Any, Iterable

from ..models import Artifact, EvidenceRecord
from .base import ExtractorContext, record
from .text import NETWORK_COMMAND, _command_endpoint


NETWORK_SECURITY_IDS = {5152, 5154, 5156, 5157, 5158}
LOGON_IDS = {4624, 4625}
RDP_IDS = {21, 22, 23, 24, 25, 39, 40, 1149}
WLAN_IDS = {8000, 8001, 8002, 8003, 11000, 11001, 11002, 11003}
NETWORK_PROFILE_IDS = {10000, 10001}
DNS_IDS = {3006, 3008, 3010, 3011, 3020}


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _event_data(root: ET.Element) -> dict[str, str]:
    values: dict[str, str] = {}
    unnamed = 1
    for element in root.iter():
        if _local(element.tag) not in {"Data", "Param", "Property"}:
            continue
        name = element.attrib.get("Name") or f"Param{unnamed}"
        if "Name" not in element.attrib:
            unnamed += 1
        values[name] = element.text or ""
    return values


def _find_text(root: ET.Element, name: str) -> str | None:
    for element in root.iter():
        if _local(element.tag) == name:
            return element.text
    return None


def _provider(root: ET.Element) -> str:
    for element in root.iter():
        if _local(element.tag) == "Provider":
            return element.attrib.get("Name", "")
    return ""


def _time(root: ET.Element) -> str | None:
    for element in root.iter():
        if _local(element.tag) == "TimeCreated":
            return element.attrib.get("SystemTime")
    return None


def _first(data: dict[str, str], *names: str) -> str | None:
    lower = {key.casefold(): value for key, value in data.items()}
    for name in names:
        value = lower.get(name.casefold())
        if value not in {None, "", "-"}:
            return value
    return None


def _port(value: str | None) -> int | str | None:
    if value is None:
        return None
    try:
        return int(value, 0)
    except ValueError:
        return value


def _protocol(value: str | None) -> str | None:
    return {"6": "tcp", "17": "udp", "1": "icmp", "58": "icmpv6"}.get(value or "", value)


def _looks_address(value: str | None) -> bool:
    if not value or value in {"-", "::", "0.0.0.0", "127.0.0.1", "::1"}:
        return False
    try:
        ipaddress.ip_address(value.strip("[]"))
        return True
    except ValueError:
        return "." in value and " " not in value


class EvtxExtractor:
    name = "windows_evtx"
    categories = frozenset({"evtx"})

    def extract(self, artifact: Artifact, context: ExtractorContext) -> Iterable[EvidenceRecord]:
        try:
            from Evtx.Evtx import Evtx  # type: ignore
        except ImportError as exc:
            raise RuntimeError("python-evtx is required to parse EVTX files") from exc
        emitted = 0
        with Evtx(str(artifact.local_path)) as log:
            for evtx_record in log.records():
                if emitted >= context.max_records:
                    break
                try:
                    root = ET.fromstring(evtx_record.xml())
                except ET.ParseError:
                    continue
                event_id_text = _find_text(root, "EventID") or "0"
                try:
                    event_id = int(event_id_text)
                except ValueError:
                    continue
                provider = _provider(root)
                provider_lower = provider.casefold()
                data = _event_data(root)
                timestamp = _time(root)
                record_id = _find_text(root, "EventRecordID")
                base = {
                    "timestamp": timestamp,
                    "os": "windows",
                    "evidence_offset": getattr(evtx_record, "record_offset", lambda: None)(),
                    "record_id": record_id,
                    "details": context.redactor.mapping({"provider": provider, "event_id": event_id, **data}),
                }
                if "sysmon" in provider_lower and event_id == 3:
                    emitted += 1
                    yield record(
                        artifact,
                        kind="connection", source="sysmon_evtx", event="network_connection",
                        user=_first(data, "User"), application=_first(data, "Image"),
                        protocol=_first(data, "Protocol"), local_address=_first(data, "SourceIp", "SourceHostname"),
                        local_port=_port(_first(data, "SourcePort")), remote_address=_first(data, "DestinationIp", "DestinationHostname"),
                        remote_port=_port(_first(data, "DestinationPort")), direction="outbound",
                        status="observed", confidence="high", **base,
                    )
                    continue
                if event_id in NETWORK_SECURITY_IDS and ("security" in provider_lower or not provider_lower):
                    emitted += 1
                    direction_value = _first(data, "Direction")
                    direction = {"%%14592": "inbound", "%%14593": "outbound"}.get(direction_value or "", direction_value)
                    source_address = _first(data, "SourceAddress")
                    source_port = _port(_first(data, "SourcePort"))
                    destination_address = _first(data, "DestAddress", "DestinationAddress")
                    destination_port = _port(_first(data, "DestPort", "DestinationPort"))
                    if direction == "inbound":
                        local_address, local_port = destination_address, destination_port
                        remote_address, remote_port = source_address, source_port
                    else:
                        local_address, local_port = source_address, source_port
                        remote_address, remote_port = destination_address, destination_port
                    yield record(
                        artifact,
                        kind="connection", source="windows_filtering_platform", event=f"security_{event_id}",
                        user=_first(data, "SubjectUserName"), application=_first(data, "Application"),
                        protocol=_protocol(_first(data, "Protocol")), local_address=local_address,
                        local_port=local_port, remote_address=remote_address,
                        remote_port=remote_port, direction=direction,
                        status="allowed" if event_id in {5154, 5156, 5158} else "blocked", confidence="high", **base,
                    )
                    continue
                if event_id in LOGON_IDS:
                    logon_type = _first(data, "LogonType")
                    address = _first(data, "IpAddress", "SourceNetworkAddress")
                    if logon_type in {"3", "10"} and _looks_address(address):
                        emitted += 1
                        yield record(
                            artifact,
                            kind="connection", source="windows_security_logon", event=f"logon_{event_id}",
                            user=_first(data, "TargetUserName"), application=_first(data, "ProcessName", "AuthenticationPackageName"),
                            protocol="rdp" if logon_type == "10" else "network_logon", remote_address=address,
                            remote_port=_port(_first(data, "IpPort")), direction="inbound",
                            status="success" if event_id == 4624 else "failed", confidence="high", **base,
                        )
                        continue
                if event_id in RDP_IDS and ("terminalservices" in provider_lower or "remote" in provider_lower):
                    address = _first(data, "Address", "IpAddress", "Param3", "ClientIP")
                    if address:
                        emitted += 1
                        yield record(
                            artifact,
                            kind="connection", source="rdp_evtx", event=f"rdp_{event_id}",
                            user=_first(data, "User", "Param1"), application="Remote Desktop", protocol="rdp",
                            remote_address=address, remote_port=3389, direction="inbound",
                            status="observed", confidence="high", **base,
                        )
                        continue
                if event_id in WLAN_IDS and "wlan" in provider_lower:
                    emitted += 1
                    yield record(
                        artifact,
                        kind="connection", source="wlan_evtx", event=f"wlan_{event_id}",
                        protocol="wifi", remote_address=_first(data, "SSID", "ProfileName", "InterfaceDescription"),
                        status="observed", confidence="high", **base,
                    )
                    continue
                if event_id in NETWORK_PROFILE_IDS and "networkprofile" in provider_lower:
                    emitted += 1
                    yield record(
                        artifact,
                        kind="connection", source="network_profile_evtx", event=f"network_profile_{event_id}",
                        remote_address=_first(data, "Name", "Description", "Guid"),
                        status="connected" if event_id == 10000 else "disconnected", confidence="high", **base,
                    )
                    continue
                if event_id in DNS_IDS and "dns" in provider_lower:
                    query = _first(data, "QueryName", "Name", "Query")
                    if query:
                        emitted += 1
                        yield record(
                            artifact,
                            kind="connection", source="dns_client_evtx", event=f"dns_{event_id}",
                            application=_first(data, "ProcessName"), protocol="dns", remote_address=query,
                            remote_port=53, direction="outbound", status=_first(data, "Status", "ResultCode") or "queried",
                            confidence="high", **base,
                        )
                        continue
                if event_id == 4104 and "powershell" in provider_lower:
                    command = _first(data, "ScriptBlockText", "Param2")
                    if command and (context.include_all_commands or NETWORK_COMMAND.search(command)):
                        emitted += 1
                        yield record(
                            artifact,
                            kind="command", source="powershell_evtx", event="script_block",
                            user=_first(data, "UserId"), application="PowerShell",
                            command=context.redactor.text(command), confidence="high", **base,
                        )
                        if NETWORK_COMMAND.search(command):
                            host, port, protocol, url = _command_endpoint(command)
                            emitted += 1
                            yield record(
                                artifact,
                                kind="connection", source="powershell_evtx", event="network_command",
                                user=_first(data, "UserId"), application="PowerShell", protocol=protocol,
                                remote_address=host, remote_port=port, direction="outbound",
                                command=context.redactor.text(command), url=context.redactor.url(url),
                                confidence="medium", **base,
                            )
