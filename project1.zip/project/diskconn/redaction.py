from __future__ import annotations

import re
from typing import Any

from .utils import strip_url_credentials


SECRET_ASSIGNMENT = re.compile(
    r"(?i)(password|passwd|pwd|token|secret|api[_-]?key|private[_-]?key|presharedkey)"
    r"(\s*(?:=|:|\s)\s*)([^\s;&|]+)"
)
AUTH_HEADER = re.compile(r"(?i)(authorization\s*:\s*(?:bearer|basic)\s+)(\S+)")
CLI_SECRET = re.compile(
    r"(?i)((?:--?(?:password|passwd|token|secret|api[-_]?key)|-p)\s+)([^\s;&|]+)"
)
URL_IN_TEXT = re.compile(r"(?i)\b(?:https?|ftp)://[^\s'\"<>]+")


class Redactor:
    def __init__(self, mode: str = "safe") -> None:
        if mode not in {"safe", "none"}:
            raise ValueError("redaction mode must be 'safe' or 'none'")
        self.mode = mode

    def text(self, value: str | None) -> str | None:
        if value is None or self.mode == "none":
            return value
        value = AUTH_HEADER.sub(r"\1<redacted>", value)
        value = CLI_SECRET.sub(r"\1<redacted>", value)
        value = SECRET_ASSIGNMENT.sub(r"\1\2<redacted>", value)
        return URL_IN_TEXT.sub(lambda match: strip_url_credentials(match.group(0)), value)

    def url(self, value: str | None) -> str | None:
        if value is None or self.mode == "none":
            return value
        return strip_url_credentials(value, strip_query_values=True)

    def mapping(self, value: dict[str, Any]) -> dict[str, Any]:
        if self.mode == "none":
            return value
        clean: dict[str, Any] = {}
        for key, item in value.items():
            if re.search(r"(?i)password|passwd|token|secret|privatekey|presharedkey|keymaterial", key):
                clean[key] = "<redacted>"
            elif isinstance(item, str):
                clean[key] = self.text(item)
            else:
                clean[key] = item
        return clean
