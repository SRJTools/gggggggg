from __future__ import annotations

import hashlib
import json
import os
import platform
import tempfile
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable

from . import __version__
from .artifact_rules import category_for, normalize_evidence_path
from .collector import ArtifactCollector, CollectionLimits
from .extractors import default_extractors
from .extractors.base import ExtractorContext
from .image_access import ImageSession, image_kind, source_segments, validate_image_dependencies
from .models import Artifact, EvidenceRecord, ExtractionError
from .redaction import Redactor
from .utils import iso_utc, sha256_file


ProgressCallback = Callable[[str], None]


@dataclass(slots=True)
class AnalysisOptions:
    source: Path
    output: Path
    source_mode: str = "image"
    image_type: str = "auto"
    case_name: str = "Disk Connection Analysis"
    case_number: str = ""
    examiner: str = ""
    notes: str = ""
    redaction: str = "safe"
    calculate_hashes: bool = True
    include_all_commands: bool = True
    max_records_per_artifact: int = 100_000
    max_total_records: int = 500_000
    max_artifact_size: int = 512 * 1024 * 1024
    max_total_artifact_size: int = 20 * 1024 * 1024 * 1024


@dataclass(slots=True)
class AnalysisResult:
    case_directory: Path
    report_path: Path
    records_path: Path
    metadata_path: Path
    metadata: dict[str, object]
    summary: dict[str, object]
    records: list[EvidenceRecord] = field(repr=False)
    artifacts: list[Artifact] = field(repr=False)
    errors: list[ExtractionError] = field(repr=False)


def _utc_now() -> str:
    return iso_utc(datetime.now(timezone.utc)) or ""


def _hash_with_progress(path: Path, progress: ProgressCallback) -> str:
    size = path.stat().st_size
    digest = hashlib.sha256()
    completed = 0
    next_notice = 0
    with path.open("rb") as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            digest.update(chunk)
            completed += len(chunk)
            if size and completed >= next_notice:
                percent = int(completed * 100 / size)
                progress(f"Hashing {path.name}: {percent}%")
                next_notice = completed + 512 * 1024 * 1024
    return digest.hexdigest()


def _source_manifest(
    source: Path,
    kind: str,
    calculate_hashes: bool,
    progress: ProgressCallback,
) -> list[dict[str, object]]:
    manifest: list[dict[str, object]] = []
    for item in source_segments(source, kind):
        stat = item.stat()
        manifest.append(
            {
                "path": str(item.resolve()),
                "size": stat.st_size,
                "modified_utc": iso_utc(datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)),
                "sha256": _hash_with_progress(item, progress) if calculate_hashes else None,
            }
        )
    return manifest


def _artifact_directory_manifest(source: Path, calculate_hashes: bool) -> list[Artifact]:
    artifacts: list[Artifact] = []
    for path in sorted(item for item in source.rglob("*") if item.is_file()):
        relative = normalize_evidence_path(path.relative_to(source).as_posix())
        category = category_for(relative)
        if not category:
            continue
        stat = path.stat()
        artifacts.append(
            Artifact(
                local_path=str(path.resolve()),
                evidence_path=relative,
                category=category,
                volume="artifacts",
                size=stat.st_size,
                sha256=sha256_file(path) if calculate_hashes else None,
            )
        )
    return artifacts


def _record_fingerprint(item: EvidenceRecord) -> str:
    values = item.as_dict()
    native = values.pop("record_id", None)
    if native is not None:
        item.details.setdefault("native_record_id", native)
    raw = json.dumps(values, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]


def _counter(records: Iterable[EvidenceRecord], attribute: str) -> dict[str, int]:
    values = Counter(str(getattr(item, attribute) or "unknown") for item in records)
    return dict(values.most_common())


def build_summary(
    records: list[EvidenceRecord], artifacts: list[Artifact], errors: list[ExtractionError]
) -> dict[str, object]:
    connections = [item for item in records if item.kind == "connection"]
    commands = [item for item in records if item.kind == "command"]
    configurations = [item for item in records if item.kind == "configuration"]
    endpoints = {
        (item.remote_address.casefold(), str(item.remote_port or ""))
        for item in connections
        if item.remote_address
    }
    timestamps = sorted(item.timestamp for item in records if item.timestamp)
    return {
        "total_records": len(records),
        "connections": len(connections),
        "commands": len(commands),
        "configurations": len(configurations),
        "unique_remote_endpoints": len(endpoints),
        "artifacts": len(artifacts),
        "errors": len(errors),
        "first_timestamp": timestamps[0] if timestamps else None,
        "last_timestamp": timestamps[-1] if timestamps else None,
        "by_source": _counter(records, "source"),
        "by_protocol": _counter(connections, "protocol"),
        "by_direction": _counter(connections, "direction"),
        "by_confidence": _counter(records, "confidence"),
        "artifact_categories": dict(Counter(item.category for item in artifacts).most_common()),
    }


class AnalysisEngine:
    def __init__(self, progress: ProgressCallback | None = None) -> None:
        self.progress = progress or (lambda _message: None)

    def analyze(self, options: AnalysisOptions) -> AnalysisResult:
        source = options.source.expanduser().resolve()
        output = options.output.expanduser().resolve()
        if not source.exists():
            raise FileNotFoundError(f"Evidence source does not exist: {source}")
        if options.source_mode not in {"image", "artifacts"}:
            raise ValueError("source_mode must be 'image' or 'artifacts'")
        if options.source_mode == "image" and not source.is_file():
            raise ValueError("Image source must be a file")
        if options.source_mode == "artifacts" and not source.is_dir():
            raise ValueError("Artifact source must be a directory")
        if options.source_mode == "artifacts":
            try:
                output.relative_to(source)
            except ValueError:
                pass
            else:
                raise ValueError("Output directory cannot be inside the artifact source directory")

        kind = image_kind(source, options.image_type) if options.source_mode == "image" else "artifacts"
        if options.source_mode == "image":
            validate_image_dependencies(kind)
        if output.exists() and not output.is_dir():
            raise ValueError("Case output path must be a directory")
        if output.exists() and any(output.iterdir()):
            raise ValueError(
                "Case output directory must be empty to prevent evidence contamination"
            )
        output.mkdir(parents=True, exist_ok=True)
        started = _utc_now()
        source_manifest: list[dict[str, object]] = []
        artifacts: list[Artifact] = []
        errors: list[ExtractionError] = []

        self.progress("Preparing case and evidence manifest")
        if options.source_mode == "image":
            source_manifest = _source_manifest(
                source, kind, options.calculate_hashes, self.progress
            )
            extracted = output / "artifacts"
            extracted.mkdir(exist_ok=True)
            collector = ArtifactCollector(
                extracted,
                CollectionLimits(
                    max_artifact_size=options.max_artifact_size,
                    max_total_size=options.max_total_artifact_size,
                ),
                self.progress,
            )
            self.progress(f"Opening {kind.upper()} image in read-only/no-mount mode")
            with tempfile.TemporaryDirectory(prefix="diskconn-work-", dir=output) as work:
                with ImageSession(source, Path(work), kind=kind) as session:
                    views = session.filesystems()
                    for view in views:
                        collector.collect_filesystem(view)
            artifacts = collector.artifacts
            errors.extend(collector.errors)
        else:
            self.progress("Indexing supplied artifact directory")
            artifacts = _artifact_directory_manifest(source, options.calculate_hashes)
            source_manifest = [
                {
                    "path": str(source),
                    "size": sum(item.size or 0 for item in artifacts),
                    "sha256": None,
                    "note": "Directory source; individual artifact hashes are in artifact_manifest.json",
                }
            ]

        self.progress(f"Parsing {len(artifacts)} collected artifacts")
        redactor = Redactor(options.redaction)
        context = ExtractorContext(
            redactor=redactor,
            max_records=options.max_records_per_artifact,
            include_all_commands=options.include_all_commands,
        )
        extractors = default_extractors()
        records: list[EvidenceRecord] = []
        limit_reached = False
        for index, artifact in enumerate(artifacts, 1):
            matching = [item for item in extractors if artifact.category in item.categories]
            if not matching:
                continue
            self.progress(
                f"Parsing artifact {index}/{len(artifacts)}: {artifact.evidence_path}"
            )
            for extractor in matching:
                try:
                    for item in extractor.extract(artifact, context):
                        item.record_id = _record_fingerprint(item)
                        records.append(item)
                        if len(records) >= options.max_total_records:
                            limit_reached = True
                            break
                except Exception as exc:
                    errors.append(
                        ExtractionError(
                            stage="parsing",
                            message=str(exc),
                            evidence_path=artifact.evidence_path,
                            extractor=extractor.name,
                            exception_type=type(exc).__name__,
                        )
                    )
                if limit_reached:
                    break
            if limit_reached:
                errors.append(
                    ExtractionError(
                        stage="parsing",
                        message=f"Global record limit reached ({options.max_total_records})",
                    )
                )
                break

        records.sort(key=lambda item: (item.timestamp is None, item.timestamp or "", item.source))
        summary = build_summary(records, artifacts, errors)
        completed = _utc_now()
        metadata: dict[str, object] = {
            "schema_version": "1.0",
            "tool": "DiskConn Forensics",
            "tool_version": __version__,
            "case_name": options.case_name,
            "case_number": options.case_number,
            "examiner": options.examiner,
            "notes": options.notes,
            "started_utc": started,
            "completed_utc": completed,
            "analysis_host": platform.platform(),
            "source_mode": options.source_mode,
            "image_type": kind,
            "no_mount": True,
            "read_only": True,
            "redaction": options.redaction,
            "source_manifest": source_manifest,
            "limits": {
                "records_per_artifact": options.max_records_per_artifact,
                "total_records": options.max_total_records,
                "artifact_size": options.max_artifact_size,
                "total_artifact_size": options.max_total_artifact_size,
            },
            "process_id": os.getpid(),
            "summary": summary,
        }

        from .report import write_case_outputs

        self.progress("Writing forensic exports and HTML report")
        paths = write_case_outputs(output, metadata, summary, records, artifacts, errors)
        self.progress(f"Complete: {paths['report']}")
        return AnalysisResult(
            case_directory=output,
            report_path=paths["report"],
            records_path=paths["records_jsonl"],
            metadata_path=paths["case_json"],
            metadata=metadata,
            summary=summary,
            records=records,
            artifacts=artifacts,
            errors=errors,
        )
