"""DiskConn: no-mount connection artifact extraction for forensic images."""

__version__ = "1.0.0"
