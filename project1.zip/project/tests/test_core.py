from __future__ import annotations

import sqlite3
import tempfile
import unittest
import hashlib
from contextlib import closing
from pathlib import Path

from diskconn.analysis import AnalysisEngine, AnalysisOptions
from diskconn.artifact_rules import category_for
from diskconn.redaction import Redactor


class RuleTests(unittest.TestCase):
    def test_windows_and_linux_artifact_rules(self) -> None:
        self.assertEqual(
            category_for("/Windows/System32/sru/SRUDB.dat"), "srum"
        )
        self.assertEqual(
            category_for("/Users/alice/NTUSER.DAT"), "registry_user"
        )
        self.assertEqual(
            category_for("/var/log/nginx/access.log.1.gz"), "web_access_log"
        )

    def test_redaction(self) -> None:
        redactor = Redactor("safe")
        value = redactor.text("curl -H 'Authorization: Bearer abc123' https://u:p@example/a?token=abc")
        self.assertNotIn("abc123", value or "")
        self.assertEqual(
            redactor.url("https://u:p@example.test/a?token=abc&x=1"),
            "https://example.test/a?token=<redacted>&x=<redacted>",
        )


class EndToEndTests(unittest.TestCase):
    def test_artifact_directory_report(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "source"
            output = Path(temporary) / "case"
            firewall = root / "Windows/System32/LogFiles/Firewall/pfirewall.log"
            firewall.parent.mkdir(parents=True)
            firewall.write_text(
                "#Version: 1.5\n"
                "#Fields: date time action protocol src-ip dst-ip src-port dst-port size\n"
                "2026-01-02 03:04:05 ALLOW TCP 10.0.0.5 203.0.113.9 50000 443 60\n",
                encoding="utf-8",
            )
            history = root / "Users/alice/AppData/Roaming/Microsoft/Windows/PowerShell/PSReadLine/ConsoleHost_history.txt"
            history.parent.mkdir(parents=True)
            history.write_text("ssh alice@example.test\nGet-ChildItem\n", encoding="utf-8")
            browser = root / "Users/alice/AppData/Local/Google/Chrome/User Data/Default/History"
            browser.parent.mkdir(parents=True)
            with closing(sqlite3.connect(browser)) as database:
                database.executescript(
                    "CREATE TABLE urls(id INTEGER PRIMARY KEY,url TEXT,title TEXT,visit_count INTEGER,typed_count INTEGER);"
                    "CREATE TABLE visits(id INTEGER PRIMARY KEY,url INTEGER,visit_time INTEGER,transition INTEGER);"
                    "INSERT INTO urls VALUES(1,'https://example.test/path?secret=yes','Example',1,0);"
                    "INSERT INTO visits VALUES(1,1,13348540800000000,0);"
                )
                database.commit()
            browser_hash = hashlib.sha256(browser.read_bytes()).hexdigest()
            result = AnalysisEngine().analyze(
                AnalysisOptions(
                    source=root,
                    output=output,
                    source_mode="artifacts",
                    calculate_hashes=True,
                )
            )
            self.assertTrue(result.report_path.is_file())
            self.assertTrue((output / "connections.csv").is_file())
            self.assertTrue((output / "output_checksums.sha256").is_file())
            self.assertGreaterEqual(int(result.summary["connections"]), 3)
            report = result.report_path.read_text(encoding="utf-8")
            self.assertIn("READ ONLY / NO MOUNT", report)
            self.assertNotIn("secret=yes", report)
            self.assertEqual(hashlib.sha256(browser.read_bytes()).hexdigest(), browser_hash)


if __name__ == "__main__":
    unittest.main()
