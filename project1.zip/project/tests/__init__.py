"""DiskConn test suite."""
